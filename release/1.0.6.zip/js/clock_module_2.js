document.head.appendChild(UI.createElem({
	tag: "style",
	attr: [{tag: "id", value: "watch_style"}],
	content:
		"#watch{"+
			"border-radius: 50%;"+
		    "width: 410px;"+
		    "height: 410px;"+
		    "background-color: rgba(255, 255, 255, 0.17);"+
		    "display: flex;"+
		    "align-items: center;"+
		    "justify-content: center;"+
		    "position: relative;"+
		    "box-shadow: 0 0 14px rgba(0, 0, 0, 0.19);"+
		    "background-color: #f6f5f3;"+
		    "transition: background-color 0.3s ease, opacity 0.3s ease"+
		"}"+
		".hoursArrow, .minutsArrow, .secondsArrow, .serif{"+
		    "width: 0;"+
		    "height: 0;"+
		    "z-index: 1;"+
		    "position: relative;"+
		    "transition: transform 0.3s cubic-bezier(0.43, 0.08, 0.52, 1.72); "+
		"}"+
		".noAnim .hoursArrow, .noAnim .minutsArrow, .noAnim .secondsArrow{"+
		    "transition: transform 0s;"+
		"}"+
		".hoursArrow div, .minutsArrow div, .secondsArrow div{height: 70px; background-color: #000;}"+
		".minutsArrow div, .secondsArrow div{height: 130px;}"+
		".secondsArrow div{background-color: #de3e3e;}"+
		".serif div{"+
		    "width: 4px;"+
		    "bottom: 160px;"+
		    "height: 30px;"+
		    "background-color: #c1c1c1;"+
		    "margin-left: -2px;"+
		    "position: absolute;"+
		"}"+
		".serif div:last-child{bottom: initial; top: 160px;}"+
		".serif:nth-child(2){transform: rotate(30deg);}"+
		".serif:nth-child(3){transform: rotate(60deg);}"+
		".serif:nth-child(4){transform: rotate(90deg);}"+
		".serif:nth-child(5){transform: rotate(120deg);}"+
		".serif:nth-child(6){transform: rotate(150deg);}"+
		".circle, .circle.seconds{"+
		   "position: absolute;"+
		   "width: 16px;"+
		   "height: 16px;"+
		    "z-index: 1;"+
		   "background-color: #000;"+
		   "border-radius: 50%;"+ 
		"}"+
		".circle.seconds{width: 10px; height: 10px; background-color: #de3e3e;}"+
		"#watch.am{background-color: #212121;}"+
		".am .hoursArrow div, .am .minutsArrow div, .am .circle:not(.seconds){background-color: #fff;}"+
		".am .serif div{background-color: #696969;}"+
		".am h2{color: #fff !important;}"+
		"#watch.pm div {box-shadow: 0 0 6px rgba(0, 0, 0, 0.32);}"
}).element);
(function(){
	var machine = {
		constructorSettingsClock: constructorSettingsClock,
		drawClock: drawClock,
		updateWatch: updateWatch
	};
	Window.WATCH = machine;

	function constructorSettingsClock(wraper, moveWatchFunction){
		console.log("CONNECT CLOCK MODULE 2");
		Window.DB.changeFile("/settings/watch_2.json", function(file){						
			loadConstructor(file, wraper, moveWatchFunction);
		}, function(isSuccess){
			if(!isSuccess) createClockData(function(){
				console.info("CREATE DATA CLOCK");
				constructorSettingsClock(wraper, moveWatchFunction);
			});
		});
	}

	function loadConstructor(data, wraper, moveWatchFunction){
		wraper.appendChild([		
			UI.createInfoWrap({
				text: "Размер часов",
				elem: UI.createSelection({
					options: ["Маленькие", "Средние", "Большие"],
					value: data.size,
					click: function(value){
						Window.DB.changeFile("/settings/watch_2.json", function(file, saveFile){
							file.size = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Жирность стрелок циферблата",
				elem: UI.createSelection({
					options: ["Тонкий", "Нормальный", "Жирный"],
					value: data.width_clock,
					click: function(value){
						Window.DB.changeFile("/settings/watch_2.json", function(file, saveFile){
							file.width_clock = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Жирность шрифта даты",
				elem: UI.createSelection({
					options: ["Тонкий", "Нормальный", "Жирный"],
					value: data.width_date,
					click: function(value){
						Window.DB.changeFile("/settings/watch_2.json", function(file, saveFile){
							file.width_date = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "",
				elem: UI.createButton({
					settings: {
						content: "Переместить часы"
					},
					click: function(value){
						moveWatchFunction(function(result){
							//console.log(result);
							Window.DB.changeFile("/settings/watch_2.json", function(file, saveFile){
								file.position = result;
								data = file;
								saveFile(file);
							}, function(isSuccess){
								drawClock(data);
								notification();
							});
						}, data.position);
					}
				})
			})
		]);
	}

	function createClockData(callback){
		Window.DB.set("/settings/", {
			file: new Blob([JSON.stringify({
				size: 2,
				width_clock: 2,
				width_date: 0,
				position: {
					top: null,
					left: null,
					right: null,
					bottom: null,
					center: {
						x: true,
						y: true
					}
				}
			})], {type: "application/json"}),
			name: "watch_2.json"
		}, callback)
	}
	/*
		Отрисока часов
	*/
	var time_format;

	function drawClock(data){
		if(!data){
			Window.DB.changeFile("/settings/watch_2.json", function(file){
				drawClock(file);
			});
			return;
		}
		if(document.getElementById("watch")){
			UI.createElem(document.getElementById("watch")).addClass("hide", function(){
				document.getElementById("watch").remove();
				drawClock(data);
			});
			return;
		}	
		var watch = UI.createElem({
			class: "watch hide "+((time_format)? "am" : "pm"),
			attr: [{tag: "id", value: "watch"}],
			style: ["width: "+([200, 300, 550][data.size])+"px;", "height: "+([200, 300, 550][data.size])+"px;"]
		});
		let serifDat = {
			height: [80, 110, 220][data.size]+"px;",
			common: "width: "+[2, 4, 8][data.width_clock]+"px;"+
					"margin-left: -"+[1, 2, 4][data.width_clock]+"px;"+
					"height: "+[15, 30, 40][data.size]+"px;"
		};
		watch.appendChild([
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({class: "serif", content: [
				UI.createElem({style: ["bottom: "+serifDat.height, serifDat.common]}),
				UI.createElem({style: ["top: "+serifDat.height, serifDat.common]})
			]}),
			UI.createElem({
				tag: "div",
				class: "hoursArrow",
				attr: [{tag: "id", value: "watch_element_clock_hours"}],
				content: UI.createElem({
					style: [
						"height: "+([50, 80, 170][data.size])+"px;",
						"width: "+([8, 8, 16][data.width_clock])+"px;",
						"margin-left: "+([-4, -4, -8][data.width_clock])+"px;"
					]
				})
			}),
			UI.createElem({
				tag: "div",
				class: "minutsArrow",
				attr: [{tag: "id", value: "watch_element_clock_minuts"}],
				content: UI.createElem({
					style: [
						"height: "+([60, 120, 200][data.size])+"px;",
						"width: "+([6, 6, 12][data.width_clock])+"px;",
						"margin-left: "+([-3, -3, -6][data.width_clock])+"px;"
					]
				})
			}),
			UI.createElem({
				class: "circle",
				style: ["width: "+([16, 18, 22][data.size])+"px;", "height: "+([16, 18, 22][data.size])+"px;"]
			}),
			UI.createElem({
				tag: "div",
				class: "secondsArrow",
				attr: [{tag: "id", value: "watch_element_clock_seconds"}],
				content: UI.createElem({
					style: [
						"height: "+([60, 120, 200][data.size])+"px;",
						"width: "+([4, 6, 8][data.width_clock])+"px;",
						"margin-left: "+([-2, -3, -4][data.width_clock])+"px;"
					]
				})
			}),
			UI.createElem({
				class: "circle seconds",
				style: ["width: "+([8, 10, 12][data.size])+"px;", "height: "+([8, 10, 12][data.size])+"px;"]
			}),
			UI.createElem({
				tag: "h2",
				content: "перезагрузите страницу, либо восстановите данные",
				attr: [{tag: "id", value: "watch_element_date"}],
				style: [
					"margin: 0;",
					"color: #000;",
					"position: absolute;",
					"margin-top: "+[32, 48, 110][data.size]+"px;",
					"font-size: "+([18, 24, 48][data.size])+"px;",
					"font-weight: "+["100", "500", "900"][data.width_date]+";"
				]
			})
		]);		
		TIME.convertPosition(data.position, watch.element);
		document.getElementById("watch_wraper").appendChild(watch.element);
		updateWatch();
		setTimeout(function(){
			watch.removeClass("hide");
		}, 50);
	}

	function updateWatch(){
		if(!document.getElementById("watch")) return;
		var watch_clock_hours = document.getElementById("watch_element_clock_hours");
		var watch_clock_minuts = document.getElementById("watch_element_clock_minuts");
		var watch_clock_seconds = document.getElementById("watch_element_clock_seconds");
		var watch_date = document.getElementById("watch_element_date");
		var date = new Date();
		var time = TIME.getTime(false);

		watch_clock_hours.style.transform = "rotate("+(180+(recovery(time.hours, 12)/12)*360)+"deg)";
		watch_clock_minuts.style.transform = "rotate("+(180+(recovery(time.minutes, 60)/60)*360)+"deg)";
		watch_clock_seconds.style.transform = "rotate("+(180+(recovery(time.seconds, 60, true)/60)*360)+"deg)";
		watch_date.innerHTML = TIME.getDay(date.getDay(), true)+" "+TIME.toDouble(date.getDate())+
			" "+TIME.getMonth(date.getMonth(), true);
		//console.log(time.litter);
		if(((time.hours >= 9)&&(time.litter == "pm"))||((time.hours < 8)&&(time.litter == "am"))){					
			if(!time_format)  document.getElementById("watch").classList.add("am");
			time_format = true;	
		}else{					
			if(time_format) document.getElementById("watch").classList.remove("am");
			time_format = false;
		}
		/*if(time.litter == "am" != time_format){
			console.log("am")
			time_format = true;			
			document.getElementById("watch").classList.add("am");
		}else{
			console.log("pm")
			time_format = false;		
			document.getElementById("watch").classList.remove("am")
		}*/

		setTimeout(function(){
			document.getElementById("watch").classList.add("noAnim");
			setTimeout(function(){
				/*watch_clock_hours.style.transform = "rotate("+(180+(+time.hours/12)*360)+"deg)";
				watch_clock_minuts.style.transform = "rotate("+(180+(+time.minutes/60)*360)+"deg)";
				watch_clock_seconds.style.transform = "rotate("+(180+(+time.seconds/60)*360)+"deg)";*/
				if(+time.hours == 0)
					watch_clock_hours.style.transform = "rotate("+(180+(recovery(time.hours, 12)/12)*360)+"deg)";
				if(+time.minutes == 0)
					watch_clock_minuts.style.transform = "rotate("+(180+(recovery(time.minutes, 60)/60)*360)+"deg)";
				if(+time.seconds == 0)
					watch_clock_seconds.style.transform = "rotate("+180+"deg)";
				setTimeout(function(){
					document.getElementById("watch").classList.remove("noAnim");
				}, 100);
			}, 100);
		}, 300);

		function recovery(val, max, show){
			return (+val == 0)? max : +val;
		}
	}
	
}());