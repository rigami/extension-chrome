var now_menu_expand = {};
var header_menu = null;

function openMenu(){
	header_menu = UI.createElem({class: "head_bg", style: [localStorage.getItem("bg_preview_now_set")+";"]});
	document.getElementById("interfaceWraper").classList.add("openMenu");
	body.appendChild(UI.createButton({
		click: closeMenu,
		settings: {
			class: "clear bgCloseButton"
		}
	}));
	var mainCntr = UI.createElem({
		class: "settings_block"
	});
	body.appendChild(mainCntr);
	mainCntr.appendChild(UI.createElem({
		tag: "h1",
		class: "logo",
		content: [
			UI.createElem({content: "ClockTab"}),
			header_menu
		]
	}));

	

	/*--------------------------------------------------------------------------------------*/
	/*-------------------------------НАСТРОЙКА ЧАСОВ----------------------------------------*/
	/*--------------------------------------------------------------------------------------*/

	mainCntr.appendChild(UI.createButton({
		click: function(event, elem){
			expandSmallMenu(elem, function(block, closeBlock, openBlock, addedCloseFunction){
				Window.DB.changeFile("/settings/settings.json", function(file){
					constructorClockSettingsMenu(block, closeBlock, openBlock, addedCloseFunction, file);
					openBlock();
				});				
			}); 				
		},
		settings: {
			class: "clear settings_button",
			style: ["background-image: url(../image/ic_watch_later_black_24dp_1x.png)"],
			content: "Часы"
		}
	}));

	function constructorClockSettingsMenu(block, closeBlock, openBlock, addedCloseFunction, data){
		/*
			RIGHT MENU
		*/
		block.appendChild([
			UI.createInfoWrap({
				text: "Вид часов",
				elem: UI.createSelection({
					options: ["Без часов", "Обычные", "Циферблат", "Вертикальные"/*, "Перекедные"*/],
					value: data.type_of_watch,
					click: function(value){
						Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
							file.type_of_watch = value;
							data = file;
							constructorClockSettings(value, function(wraper){
								connectModule("js/clock_module_"+value+".js", value, wraper, function(){
									saveFile(file);
								});								
							});							
						},	function(isSuccess){
							if((data.type_of_watch == 0)&&(document.getElementById("watch"))){
								UI.createElem(document.getElementById("watch")).addClass("hide", function(){
									document.getElementById("watch").remove();
								});
							}
							if(data.type_of_watch != 0) Window.WATCH.drawClock();
							notification(isSuccess);
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Уровень затеменения фона",
				elem: UI.createSelection({
					options: ["Без затемнения", "Слабо", "Нормально", "Сильно"],
					value: data.background_dimming_level,
					click: function(value){
						Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
							file.background_dimming_level = value;
							data = file;
							saveFile(file);
						}, notification);
					},
					hover: function(value){
						document.getElementById("blind").style.backgroundColor =
							"rgba(0,0,0,"+[0, 0.17, 0.3, 0.6][value]+")";
					}
				})
			})
		]);

		function connectModule(src, value, wraper, callback){
			if(value == 0){
				if(document.getElementById("watch_module")) document.getElementById("watch_module").remove();
				callback();
				return;
			}
			document.head.appendChild((function(){
				if(document.getElementById("watch_module")) document.getElementById("watch_module").remove();
				if(document.getElementById("watch_style")) document.getElementById("watch_style").remove();
				delete Window.WATCH;
				var script = document.createElement("script");
				script.setAttribute("src", src);
				script.setAttribute("id", "watch_module");
				script.onload = function(){
					Window.WATCH.constructorSettingsClock(wraper, function(callback, oldPosition){
						document.getElementById("watch").classList.add("moveWatch");
						UI.createElem(document.getElementById("interfaceWraper")).addClass("hide", function(){
							document.getElementById("interfaceWraper").classList.add("displayNone");
							moveWatch(callback, oldPosition);					
						});
					});
					callback();
				}
				return script;
			})());
		};

		/*
			LEFT MENU
		*/
		var rightMenu = UI.createElem({class: "settings_rightMenu hide"});
		var gl_clockBlock = undefined;		

		function constructorClockSettings(type, callback){
			if(gl_clockBlock){	
				gl_clockBlock.addClass("hide", function(){
					gl_clockBlock.remove();
					gl_clockBlock = undefined;
					constructorClockSettings(type, callback);
				});
				return;
			}
			if(type == 0){
				callback();
				return;
			}
			gl_clockBlock = UI.createElem({class: "settings_dayManager settings_dayManager_wraper hide"});
			gl_clockBlock.appendChild(UI.createElem({
				tag: "h1",
				class: "ahead",
				content: ["", "Обычные", "Перекедные", "Вертикальные", "Циферблат"][type]
			}));
			gl_clockBlock.type = type;
			callback(gl_clockBlock);
			rightMenu.appendChild(gl_clockBlock);
			setTimeout(function(){
				gl_clockBlock.removeClass("hide");
			}, 50);
		}
		constructorClockSettings(data.type_of_watch, function(wraper){
			connectModule("js/clock_module_"+data.type_of_watch+".js", data.type_of_watch, wraper, function(){

			});								
		});

		//rightMenuTest//body.appendChild(rightMenu);
		block.appendChild(rightMenu);
		setTimeout(function(){
			rightMenu.removeClass("hide");
		}, 50);

		addedCloseFunction(function(){
			rightMenu.addClass("hide", function(){
				rightMenu.remove();
			});					
		});
	}

	/*--------------------------------------------------------------------------------------*/
	/*--------------------------------НАСТРОЙКА ФОНА----------------------------------------*/
	/*--------------------------------------------------------------------------------------*/

	mainCntr.appendChild(UI.createButton({
		click: function(event, elem){
			expandSmallMenu(elem, function(block, closeBlock, openBlock, addedCloseFunction){
				Window.DB.changeFile("/settings/settings.json", function(fileS){
					Window.DB.changeFile("/settings/backgroundsList.json", function(fileBG){
						constructorBackGroundsSettingsMenu(block, closeBlock, openBlock, addedCloseFunction, fileS, fileBG);
						openBlock();
					});
				});				
			}); 	
		},
		settings: {
			class: "clear settings_button",
			style: ["background-image: url(../image/ic_panorama_black_24dp_1x.png)"],
			content: "Фон и планировщик"
		}
	}));

	function constructorBackGroundsSettingsMenu(block, closeBlock, openBlock, addedCloseFunction, data, dataBG){
		/*RIGHT MENU*/
		/*
			Выбор дней переключения фонов
		*/
		var daysCheckBoxs = [
			UI.createCheckBox({
				click: function(value){
					driveDayManager(0, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[0],
				content: "Понедельник"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(1, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[1],
				content: "Вторник"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(2, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[2],
				content: "Среда"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(3, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[3],
				content: "Четверг"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(4, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[4],
				content: "Пятница"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(5, value, false, allDaysSwitcher.value);
				},
				value: data.background_switching_days[5],
				content: "Суббота"
			}),
			UI.createCheckBox({
				click: function(value){
					driveDayManager(6, value, false, allDaysSwitcher.value);							
				},
				value: data.background_switching_days[6],
				content: "Воскресенье"
			})
		];
		var allDaysSwitcher = UI.createSwitcher({
			click: function(value){
				Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
					file.one_setting_for_selected_days = value;
					data = file;
					saveFile(file);
				}, function(isSuccess){
					getBackground(data);
					notification();
				});
				if(value){
					for(var i=0; i<7; i++) driveDayManager(i, false, true);
					driveDayManager(7, value, true);	
				}else{
					daysCheckBoxs.forEach(function(object, i){
						if(object.value) driveDayManager(i, true, true);
					});
					driveDayManager(7, value, true);
				}
					
			},
			value: data.one_setting_for_selected_days,
			content: "Общие настройки для выбраных дней"
		});
		block.appendChild([
			UI.createInfoWrap({
				text: "Загрузите свои фон, либо выберете из каталога",
				elem: UI.createButton({
					click: function(){
						BGManagerConstructor();
					},
					settings: {
						content: "Библиотека"
					}
				})
			}),
			UI.createElem({
				tag: "h2",
				content: "Дни смены фона"
			}),
			daysCheckBoxs,
			allDaysSwitcher
		]);
		/*LEFT MENU*/
		/*
			Настройка дней
		*/
		var rightMenu = UI.createElem({class: "settings_rightMenu hide"});		
		daysCheckBoxs.forEach(function(object, i){
			rightMenu.appendChild(UI.createElem({
				attr: [{tag: "id", value: "settings_rightMenu_manager_"+i}],
				class: (((object.value)&&(!data.one_setting_for_selected_days))? "" : "hide") +
					" settings_dayManager_wraper",
				content: ((object.value)&&(!data.one_setting_for_selected_days))? dayManager(i) : undefined
			}));
		});
		rightMenu.appendChild(UI.createElem({
			attr: [{tag: "id", value: "settings_rightMenu_manager_7"}],
			class: ((data.one_setting_for_selected_days)? "" : "hide") + " settings_dayManager_wraper",
			content: (data.one_setting_for_selected_days)? dayManager(7) : undefined
		}));
		//rightMenuTest//body.appendChild(rightMenu);
		block.appendChild(rightMenu);
		setTimeout(function(){
			rightMenu.removeClass("hide");
		}, 50);

		function driveDayManager(day, act, notChange, saveOnly){
			{
				let checkValue = true;
				for(var i = 0; i < 7; i++)
					if(daysCheckBoxs[i].value){
						checkValue = false;
						break;
					}
				if(checkValue){
					daysCheckBoxs[day].setValue(true);
				}
			}
			if(!notChange){
				Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
					file.background_switching_days[day] = act;
					data = file;
					saveFile(file);
				}, function(isSuccess){
					getBackground(data);
					notification();
				});
			}
			if(saveOnly) return;
			if(act){
				document.getElementById("settings_rightMenu_manager_"+day).appendChild(dayManager(day).element);
				document.getElementById("settings_rightMenu_manager_"+day).classList.remove("hide");
			}else{
				document.getElementById("settings_rightMenu_manager_"+day).classList.add("hide");
				setTimeout(function(){
					document.getElementById("settings_rightMenu_manager_"+day).innerHTML = "";
				}, 300);
			}
		}

		function dayManager(day){
			var daySettingsName = "switching_background_in_"+["mo", "tu", "we", "th", "fr", "sa", "su", "special"][day];
			var gl_dayBlock = UI.createElem({class: "settings_dayManager"});
			gl_dayBlock.appendChild(UI.createElem({
				tag: "h1",
				class: "ahead",
				content: [
					"Понедельник",
					"Вторник",
					"Среда",
					"Четверг",
					"Пятница",
					"Суббота",
					"Воскресенье",
					"Смена в выбранные дни"
				][day]
			}));
			gl_dayBlock.appendChild(UI.createInfoWrap({
				text: "Как выбирать фон",
				elem: UI.createSelection({
					options: ["Случайно", "Конкретно"],
					value: data[daySettingsName].background_selection,
					click: function(value){						
						switch(value){
							case 0: 
								randomConstructor();
								Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
									file[daySettingsName].background_selection = value;
									data = file;
									saveFile(file);
								}, function(isSuccess){
									getBackground(data);
									notification();
								});
								break;
							case 1:
								specificallyConstructor(true);
								Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
									file[daySettingsName].background_selection = value;
									data = file;
									saveFile(file);
								});
								break;
						}
					}
				})
			}));
			let settingsConstructor;
			function randomConstructor(){
				var wraperRandom = UI.createElem({
					class: (!settingsConstructor)? "hide" : ""
				});
				wraperRandom.appendChild(UI.createInfoWrap({
					text: "Когда менять фон",
					elem: UI.createSelection({
						options: [
							"При открытии",
							"Каждые 5 минут",
							"Каждые 30 минут",
							"Кажый час",
							"Каждые 6 часов",
							"Каждые 12 часов",
							"Раз в день"
						],
						value: data[daySettingsName].random_selection.period,
						click: function(value){
							Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
								file[daySettingsName].random_selection.period = value;
								data = file;
								saveFile(file);
							}, function(isSuccess){
								getBackground(data);
								notification();
							});
						}
					})
				}));
				wraperRandom.appendChild(UI.createElem({
					tag: "p",
					content: "Какие фоны выбирать"
				}));
				var tBut = [
					UI.createCheckBox({
						click: function(value){
							editUsingType(0, value);
						},
						value: data[daySettingsName].random_selection.type[0],
						content: "Видео"
					}),
					UI.createCheckBox({
						click: function(value){
							editUsingType(1, value);
						},
						value: data[daySettingsName].random_selection.type[1],
						content: "Изображения"
					}),
					UI.createCheckBox({
						click: function(value){
							editUsingType(2, value);
						},
						value: data[daySettingsName].random_selection.type[2],
						content: "Сплошные цвета"
					})
				];
				wraperRandom.appendChild(tBut);

				function editUsingType(useType, setValue){
					{
						data[daySettingsName].random_selection.type[useType] = setValue;
						let tActive = data[daySettingsName].random_selection.type;
						if(!(tActive[0] || tActive[1] || tActive[2])){
							tBut[useType].setValue(true);
							data[daySettingsName].random_selection.type[useType] = !setValue;
							return;
						}
					}
					Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
						file[daySettingsName].random_selection.type[useType] = setValue;
						data = file;
						saveFile(file);
					}, function(isSuccess){
						getBackground(data);
						notification();
					});
				}
				/*wraperRandom.appendChild(UI.createCheckBox({
					click: function(value){

					},
					value: data[daySettingsName].random_selection.type[0],
					content: "Живые обои"
				}));*/
				/*wraperRandom.appendChild(UI.createInfoWrap({
					text: "Какие фоны выбирать",
					elem: UI.createSelection({
						options: [
							"Только изображения",
							"Только видео",
							"Любые"
						],
						value: data[daySettingsName].random_selection.type,
						click: function(value){
							Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
								file[daySettingsName].random_selection.type = value;
								data = file;
								saveFile(file);
							}, function(isSuccess){
								getBackground(data);
								notification();
							});
						}
					})
				}));*/
				gl_dayBlock.appendChild(wraperRandom);					
				if(settingsConstructor)
					settingsConstructor.addClass("hide", function(){
						settingsConstructor.remove();
						wraperRandom.removeClass("hide");
						settingsConstructor = wraperRandom;
					});
				else settingsConstructor = wraperRandom;
				
			}
			function specificallyConstructor(isOpenManager){
				if(isOpenManager) setSpecial(true);
				var wraperSpec = UI.createElem({
					class: (!settingsConstructor)? "hide" : "",
					style: [
						"overflow: hidden;",
						"position: relative;",
						"background-color: #000;",
						"border-radius: 0px 0px 3px 3px;",
						"margin: 0px -10px;",
						"padding: 0px 10px;"
					]
				});
				var previewBlurWraper = UI.createElem({
					class: "preview_blur",
					style: [
						(data[daySettingsName].specifically_selection.type == "color")? 
							("background-color: "+data[daySettingsName].specifically_selection.name) : 
							("background-image: url('"+Window.DB.get()+"/backgrounds/preview/"+data[daySettingsName].specifically_selection.name+"')")
					]
				});
				var typeBG = UI.createElem({
					content: (function(){
						switch(data[daySettingsName].specifically_selection.type){
							case "video": return "Видео";
							case "image": return "Изображение";
							case "color": return "Сплошной цвет";
							case "live": return "Живые обои";
						}
					})()
				});					
				wraperSpec.appendChild(previewBlurWraper);
				wraperSpec.appendChild(UI.createInfoWrap({
					text: typeBG,
					class: "preview_info",
					style: ["position: relative;"],
					styleText: ["color: #fff !important;", "font-size: 21px !important"],
					elem: UI.createButton({
						settings: {
							content: "Изменить"
						},
						click: function(){setSpecial()}
					})
				}));
				var previewBlur = UI.createElem({
					class: "preview",
					style: [
						(data[daySettingsName].specifically_selection.type == "color")? 
							("background-color: "+data[daySettingsName].specifically_selection.name) : 
							("background-image: url('"+Window.DB.get()+"/backgrounds/preview/"+data[daySettingsName].specifically_selection.name+"')")
					]
				});
				wraperSpec.appendChild(UI.createInfoWrap({
					text: "",
					style: ["position: relative;"],
					elem: previewBlur
				}));
				gl_dayBlock.appendChild(wraperSpec);					
				if(settingsConstructor)
					settingsConstructor.addClass("hide", function(){
						settingsConstructor.remove();
						wraperSpec.removeClass("hide");
						settingsConstructor = wraperSpec;
					});
				else settingsConstructor = wraperSpec;

				function setSpecial(notCloseButton){
					specialCatalogBG(function(result){
						//console.log(result)
						if(!result) return;
						var bgListV;
						Window.DB.changeFile("/settings/backgroundsList.json", function(bgList, saveFile){
							bgListV = bgList;
							bgList.background_set_now = [];
							bgList.background_set_now[0] = {};
							bgList.background_set_now[0] = bgList[result.type][result.number];
							bgList.background_set_now[0].type = result.type;
							typeBG.innerContent((function(){
								switch(result.type){
									case "video": return "Видео";
									case "image": return "Изображение";
									case "color": return "Сплошной цвет";
									case "live": return "Живые обои";
								}
							})());
							switch(result.type){
								case "color":
									previewBlurWraper.changeStyle("background-image");
									previewBlur.changeStyle("background-image");
									previewBlurWraper.changeStyle([{
										tag: "backgroundColor",
										value: result.name
									}]);
									previewBlur.changeStyle([{
										tag: "backgroundColor",
										value: result.name
									}]);
									break;
								default:
									previewBlurWraper.changeStyle([{
										tag: "backgroundImage",
										value: "url('"+Window.DB.get()+"/backgrounds/preview/"+result.name+"')"
									}]);
									previewBlur.changeStyle([{
										tag: "backgroundImage",
										value: "url('"+Window.DB.get()+"/backgrounds/preview/"+result.name+"')"
									}]);
									break;
							}
							saveFile(bgList);
						}, function(isSuccess){
							Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
								//console.log(bgListV)
								//console.log(daySettingsName);
								file[daySettingsName].specifically_selection = {
									type: result.type,
									name: result.name,
									isPixelArt: bgListV[result.type][result.number].isPixelArt
								}
								data = file;
								saveFile(file);
							}, function(isSuccess){								
								//Window.DB.changeFile("/settings/backgroundsList.json", function(a){console.log(a)});
								//Window.DB.changeFile("/settings/settings.json", function(a){console.log(a)});
								getBackground(data);
								notification();
							});
						});
					}, notCloseButton);
				}
			}

			function webConstructor(){
				var wraperWEB = UI.createElem({
					class: (!settingsConstructor)? "hide" : ""
				});
				gl_dayBlock.appendChild(wraperWEB);					
				if(settingsConstructor)
					settingsConstructor.addClass("hide", function(){
						settingsConstructor.remove();
						wraperWEB.removeClass("hide");
						settingsConstructor = wraperWEB;
					});
				else settingsConstructor = wraperWEB;
			}
			if(data[daySettingsName].background_selection)specificallyConstructor(); else randomConstructor();
			return gl_dayBlock;			
		}
		addedCloseFunction(function(){
			rightMenu.addClass("hide", function(){
				rightMenu.remove();
			});					
		});
	}

	/*--------------------------------------------------------------------------------------*/
	/*---------------------------------ДОПОЛНИТЕЛЬНО----------------------------------------*/
	/*--------------------------------------------------------------------------------------*/
/*
	mainCntr.appendChild(UI.createButton({
		click: function(event, elem){
			expandSmallMenu(elem, function(block, closeBlock, openBlock, addedCloseFunction){
				Window.DB.changeFile("/settings/settings.json", function(file){
					constructorMoreMenu(block, closeBlock, openBlock, addedCloseFunction, file);
					openBlock();
				});				
			}); 				
		},
		settings: {
			class: "clear settings_button",
			style: ["background-image: url(../image/ic_bubble_chart_black_24dp_1x.png)"],
			content: "Дополнительно"
		}
	}));

	function constructorMoreMenu(block, closeBlock, openBlock, addedCloseFunction, data){
		
		//	RIGHT MENU
		
		block.appendChild([
			UI.createCheckBox({
				click: function(value){
					Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
						file.focus_search_field = value;
						data = file;
						saveFile(file);										
					},	notification);
				},
				value: data.focus_search_field,
				content: "Фокус на адресную стрку при открытии"
			})
		]);

		//  LEFT MENU

		var rightMenu = UI.createElem({class: "settings_rightMenu hide"});

		rightMenu.appendChild([
			UI.createElem({
				class: "settings_dayManager settings_dayManager_wraper",
				content: [
					UI.createElem({
						tag: "h1",
						class: "ahead",
						content: "Выбор фокуса при открытии новой вкладки"
					}),
					UI.createElem({
						tag: "p",
						content: "При выборе фокуса закладок вы не сможете сразу писать запрос, но зато вы можете сразу начать писать заметку"
					}),
					UI.createElem({
						tag: "p",
						content: "При выборе фокуса адресной строки при открытии вам не придется нажимать на нее для ввода запроса,"+
							" вместо этого вы можете сразу начать писать запрос."
					})
				]
			})
		]);

		body.appendChild(rightMenu);
		setTimeout(function(){
			rightMenu.removeClass("hide");
		}, 50);

		addedCloseFunction(function(){
			rightMenu.addClass("hide", function(){
				rightMenu.remove();
			});					
		});
	}
*/
	/*--------------------------------------------------------------------------------------*/
	/*----------------------------------О ПРОЕКТЕ-------------------------------------------*/
	/*--------------------------------------------------------------------------------------*/

	mainCntr.appendChild(UI.createButton({
		click: function(event, elem){
			expandSmallMenu(elem, function(block, closeBlock, openBlock){
				block.appendChild([
					UI.createElem({
						tag: "h2",
						content: "Расширение разработано Данилом Захваткиным (2017)"
					}),
					UI.createButton({
						settings:{
							content: "Другие проекты Danilkinkin",
							style: ["margin-bottom: 15px;", "margin-right: 15px;"]
						},
						click: function(){
							window.open("http://danilkinkinstudio.h1n.ru");
						}
					}),
					UI.createButton({
						settings:{
							content: "Помочь проекту",
							style: ["margin-bottom: 15px;"]
						},
						click: function(){
							window.open("http://danilkinkinstudio.h1n.ru/projects/clockTab/donate");
						}
					})
				]);
				openBlock();
			}); 	
		},
		settings: {
			class: "clear settings_button",
			style: ["background-image: url(../image/ic_info_black_24dp_1x.png)"],
			content: "О проекте"
		}
	}));

	function expandSmallMenu(button, callback){
		if(now_menu_expand.block){
			now_menu_expand.block.close(now_menu_expand);
			if(now_menu_expand == button) return;
		}
		
		var block = UI.createElem({
			tag: "div",
			class: "settings_small_block"
		});		

		function close(buttonParent){
			let ths = this;
			if(buttonParent.closeFunction) buttonParent.closeFunction()
			if(buttonParent.block.addedCloseFunction) buttonParent.block.addedCloseFunction()
			block.removeClass("expand", function(){
				block.changeStyle("height", function(){
					ths.remove();
					if(buttonParent) delete buttonParent.block;
				});
			}, 50);
		}
		block.close = close;	
		button.block = block;
		now_menu_expand = button;
		callback(block, close, function(){		
			//console.log(button)	
			button.parentNode.insertBefore(block.element, button.nextSibling);
			var heightBlock = block.element.clientHeight;
			block.addClass("zeroHeight", function(){
				block.changeStyle([{tag: "height", "value": heightBlock+"px"}], function(){
					block.addClass("expand");
				});
			}, 50);			
		},
		function(addCloseFunc){
			block.addedCloseFunction = addCloseFunc;
		});
	}


	//document.getElementById("interfaceWraper").classList.add("hide");
	setTimeout(function(){
		body.removeClass(["hide", "zeroWidth"]);

	}, 200);	
}

function specialCatalogBG(callback, notCloseButton){
	var content = UI.createElem({class: "content"});
	var BG_manager = UI.createElem({
		class: "BGManager hide",
		content: UI.createElem({
			class: "manager",
			content: [
				UI.createElem({
					class: "ahead",
					content: [
						UI.createElem({
							tag: "h1",
							content: "Выбирете фон"
						}),
						(function(){
							if(!notCloseButton) return UI.createButton({
									click: function(){
										callback(false);
										BG_manager.addClass("hide", function(){
											BG_manager.remove();									
										}, 250);								
									},
									settings: {
										class: "clear close_manager"
									}
								});
							else return UI.createElem();					
						})()						
					]
				}), content
			]
		})
	});

	var catalog = UI.createElem({class: "select_catalog"});
	content.appendChild(catalog);

	catalog.appendChild(UI.createElem({content: UI.createInfoWrap({
		class: "load_files",
		text: "Загрузите фон с компьютера",
		elem: UI.createButton({
			settings: {content: "Загрузить"},
			click: function(){localCatalogAddedLocalFile(function(file){
				//console.log(file)
				callback({type: file.type? "video" : "image", number: file.number, name: file.name});
				BG_manager.addClass("hide", function(){
					BG_manager.remove();
				}, 250);
			}, true)}
		})
	})}));
	Window.DB.changeFile("/settings/backgroundsList.json", function(file){
		var url = Window.DB.get()+"backgrounds/preview/";
		if((file.video.length == 0)&&
			   (file.image.length == 0)&&
			   (file.color.length == 0)&&
			   (file.live.length == 0)) catalog.appendChild(UI.createElem({
				class: "charter",
				style: ["text-align: center;"],
				content: "У вас еще нет ни одного фона, загрузите их, либо добавьте свои"
			}));
			if(file.video.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Видео"
			}));
			file.video.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object.name, "video", i));
			});			
			if(file.image.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Изображения"
			}));
			file.image.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object.name, "image", i));
			});
			if(file.color.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Сплошные цвета"
			}));
			file.color.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object.color, "color", i));
			});
			if(file.live.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Живые обои"
			}));
			file.live.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object.name, "live", i));
			});

		function constructorPreview(name, type, number){
			return (function(){
				var preview = UI.createButton({
					settings: {
						class: "preview clear",
						style: [(type != "color")? "background-image: url('"+url+name+"');" : "background-color: "+name+";"]
					},
					click: function(){
						callback({type: type, number: number, name: name});
						BG_manager.addClass("hide", function(){
							BG_manager.remove();
						}, 250);
					}
				});
				return preview;
			})();
		}
	});						

	globalBody.appendChild(BG_manager);
	setTimeout(function(){
		BG_manager.removeClass("hide");
	}, 50);
}

function BGManagerConstructor(openPage){
	var content = UI.createElem({class: "content"});
	var sortFunc;
	var sortBy = UI.createSelection({
		options: ["Сначала новые", "Сначала популярные"],
		click: function(val){
			sortFunc(val);
		}
	});	
	var BG_manager = UI.createElem({
		class: "BGManager hide",
		content: UI.createElem({
			class: "manager",
			content: [
				UI.createElem({
					class: "ahead",
					content: [
						UI.createElem({
							tag: "h1",
							content: "Менеджер фонов"
						}),
						UI.createSelection({
							options: ["Каталог", "Загруженные"],
							click: function(value){
								if(value == 0){
									webCatalog(function(sortFuncCal){
										sortFunc = sortFuncCal;
										sortFunc(sortBy.value);
									});

									sortBy.removeClass("DOE_hide");
								}else{
									localCatalog();
									sortBy.addClass("DOE_hide");
								}
							}
						}),
						sortBy,
						UI.createButton({
							click: function(){
								BG_manager.addClass("hide", function(){
									BG_manager.remove();
								}, 250);								
							},
							settings: {
								class: "clear close_manager"
							}
						})
					]
				}), content
			]
		})
	});
	webCatalog(function(sortFuncCal){
		sortFunc = sortFuncCal;
		sortFunc(sortBy.value);
	});
	function webCatalog(callback, bgList){
		if(!bgList){
			Window.DB.changeFile("/settings/backgroundsList.json", function(a){webCatalog(callback, a.download)});
			return;
		}		
		content.clearContent();
		var pre_cont = UI.createElem({class: "web_catalog"});
		pre_cont.appendChild(UI.createElem({
			class: "charter",
			content: "Медиа"
		}));
		var pre_cont_color = UI.createElem({class: "web_catalog"});
		pre_cont_color.appendChild(UI.createElem({
			class: "charter",
			content: "Сплошные цвета"
		}));
		pre_cont_color.appendChild((function(){
			return [
				"#ff8c00", 
				"#e81123", 
				"#d13438", 
				"#c30052",
				"#bf0077", 
				"#9a0089", 
				"#881798", 
				"#744da9", 
				"#10893e", 
				"#107c10", 
				"#018574", 
				"#2d7d9a", 
				"#0063b1", 
				"#6b69d6", 
				"#8e8cd8", 
				"#8764b8", 
				"#038387", 				 
				"#486860", 
				"#525e54", 
				"#7e735f", 
				"#4c4a48", 
				"#515c6b", 
				"#4a5459", 
				"#000000"
			].map(function(color){
				var preview = UI.createButton({
					settings:{class: "preview clear", style: ["font-size: 0;", "background-color: "+color+";"]},
					click: function(){
						preview.isDownload = preview.containsClass("download");
						var noteGWraper = UI.createElem({
							class: "manager_window previewBGinCatalog hide",
							content: [
								UI.createElem({
									tag: "div",
									style: ["width: 80%;", "height: 80%;", "box-shadow: 0 5px 12px rgba(0, 0, 0, 0.43);", "background-color: "+color+";"],
									attr: [{tag: "background-color", value: color}]
								}),
								UI.createElem({ style: ["position: absolute;", "bottom: 15px;", "right: 15px; direction: rtl;"], content: [
									UI.createButton({
										settings: {
											content: (preview.isDownload? "Фон уже добавлен" : "Добавить"),
											isEnabled: !preview.isDownload,
											log: true
										},
										click: function(){
											noteGWraper.addClass("hide", function(){
												noteGWraper.remove();
											});
											saveBackgroundFileInSystem({
												name: "color_"+color.substring(1),
												color: color,
												type: "color/",
												isLocal: false,
												urlFile: "color_"+color
											}, function(){
												notification({text: "Цвет добавлен в библиотеку"});
												preview.addClass("download");														
											});		
										}
									}),					
									UI.createButton({
										settings: {class: "light false", content: "Закрыть", style: ["margin-right: 15px;"]},
										click: function(){
											noteGWraper.addClass("hide", function(){
												noteGWraper.remove();
											})
										}
									})
								]})		
							]
						});

						globalBody.appendChild(noteGWraper);
						setTimeout(function(){
							noteGWraper.removeClass("hide");
						}, 50);
					}
				});
				if(bgList.find(elem => (elem == "color_"+color))) preview.addClass("download");					
				return preview;
			});
		})());
		var previewWraper = UI.createElem();
		content.appendChild([pre_cont, pre_cont_color]);
		var spinner = UI.createElem({
			class: "load_spinner"
		});
		var searchTags = "";
		previewWraper.appendChild(spinner);
		Window.DB.sendRequest("http://danilkinkinstudio.h1n.ru/backgrounds/getTagList.php", {},
		function(result){
			spinner.remove();
			//console.log(JSON.parse(result))
			try{
				if(JSON.parse(result).length == 0){
					previewWraper.appendChild(UI.createElem({
						tag: "h2",
						class: "info",
						content: "Данные не найдены"
					}));
					return;
				}
			}catch(e){
				previewWraper.appendChild(UI.createElem({
					tag: "h2",
					class: "info",
					content: "Неудалось загрузить данные с сервера, попробуйте позже"
				}));
				return;
			}
			var res = JSON.parse(result).map(function(curVall){
				return UI.createButton({
					click: function(){
						this.isSelect = !this.isSelect;
						if(this.isSelect){
							this.settings.object.addClass("select");							
							searchTags = ":"+curVall.id+":"+searchTags;
						}else{
							this.settings.object.removeClass("select");
							searchTags = searchTags.replace(":"+curVall.id+":", "");
						}
						//console.log(sortBy)
						search(searchTags, sortBy.value);
					},
					settings: {
						class: "clear",
						content: curVall.tag
					}
				});
			});	
			res[res.length]=previewWraper;
			pre_cont.appendChild(UI.createElem({
				class: "tag_list",
				content: res
			}));
		});

		callback(function(sortBy){
			search(searchTags, sortBy);
		})

		function search(searchTags, sortBy){
			//console.log(sortBy)
			if(searchTags)
				searchTags = "%:"+searchTags.substring(1, searchTags.length-1).split("::").map((a)=>(+a)).sort((a, b)=>(a>b)).join(":%:")+":%";
			else
				searchTags = "%";
			previewWraper.clearContent();
			previewWraper.appendChild(spinner);
			Window.DB.sendRequest("http://danilkinkinstudio.h1n.ru/backgrounds/getBGList.php", {
				searchTag: searchTags,
				sortByPopular: sortBy
			}, function(result){
				spinner.remove();
				try{
					if(JSON.parse(result).length == 0){
						previewWraper.appendChild(UI.createElem({
							tag: "h2",
							class: "info",
							content: "По данным тегам ничего не найдено"
						}));
						return;
					}
				}catch(e){
					previewWraper.appendChild(UI.createElem({
						tag: "h2",
						class: "info",
						content: "Неудалось загрузить данные, попробуйте позже"
					}));
					return;
				}			
				JSON.parse(result).forEach(function(elemInCatalog){
					var preview = UI.createButton({
						settings:{class: "preview clear", style: ["font-size: 0;"]},
						click: function(){
							preview.data.isDownload = preview.containsClass("download");
							WebCatalogDownloadFile(preview.data, previewWraper, function(){
								Window.DB.changeFile("/settings/backgroundsList.json", function(a){bgList = a.download;});
								preview.addClass("download");
								//console.log(elemInCatalog)
								Window.DB.sendRequest("http://danilkinkinstudio.h1n.ru/backgrounds/incDownloadBG.php", {
									nameBG: elemInCatalog.name
								},function(res){
									//console.log(res)
								});
							})
						}
					});	
					preview.data = elemInCatalog;
					if(bgList.find(elem => (elem == "http://"+preview.data.url+preview.data.name+"."+preview.data.type))) 
						preview.addClass("download");
					var image = new Image();
					image.src = "http://"+preview.data.url+"preview/"+preview.data.name+".jpg";
					image.onload = function(){
						preview.changeStyle([{tag: "backgroundImage", value: "url("+image.src+")"}]);
					}						
					preview.appendChild(UI.createElem({
						class: "trie",
						content: preview.data.resolution
					}));
					previewWraper.appendChild(preview);
				});
			});
		}
	}

	function WebCatalogDownloadFile(info, previewWraper, callback){
		/*addEventListener('resize', function() {
			Math.floor((previewWraper.clientWidth-10)/260)
		}, false);*/
		var spinner = UI.createElem({
			class: "load_spinner"
		});
		//console.log(info)
		var noteGWraper = UI.createElem({
			class: "manager_window previewBGinCatalog hide",
			content: [
				spinner,
				(function(){
					if(info.type != "video")
						return UI.createElem({
							tag: "img",
							style: ["max-width: 90%;", "max-height: 90%;", "box-shadow: 0 5px 12px rgba(0, 0, 0, 0.43);"],
							class: ((info.type == "gif")? "bgPIXEL" : "")+" hide",
							attr: [{tag: "src", value: "http://"+info.url+"full/"+info.name+"."+info.type}],
							special: {
								onload: function(){
									this.classList.remove("hide");
									spinner.remove();
								},
								onerror: function(){
									console.error("ERROR LOAD IMAGE");
									spinner.remove();
									notification({
										image: "../image/ic_error_white_24dp_1x.png",
										text: "Не удается загрузить фон",
										timeout: 6000
									});
									noteGWraper.remove();
								}
							}
						});
					else
						return UI.createElem({
							tag: "video",
							style: ["max-width: 90%;", "max-height: 90%;", "box-shadow: 0 5px 12px rgba(0, 0, 0, 0.43);"],
							attr: [
								{tag: "autoplay", value: "true"},
								{tag: "loop", value: "true"},
								{tag: "src", value: "http://"+info.url+"full/"+info.name+"."+info.type}
							],
							class: "hide",
							special: {
								onloadedmetadata: function(event){
									this.classList.remove("hide");
									spinner.remove();				
								},
								onerror: function(){
									console.error("ERROR LOAD VIDEO");
									spinner.remove();
									notification({
										image: "../image/ic_error_white_24dp_1x.png",
										text: "Не удается загрузить фон",
										timeout: 6000
									});
									noteGWraper.remove();
								}
							}
						});
				})(),
				UI.createElem({ style: ["position: absolute;", "bottom: 15px;", "right: 15px; direction: rtl;"], content: [
					UI.createElem({
						class: "infoAboutBGInCatalog",
						content: "Автор: "+info.author+"<br>"+
								 info.info
						
					}),
					UI.createButton({
						settings: {
							content: (info.isDownload? "Фон уже добавлен" : "Добавить"),
							isEnabled: !info.isDownload,
							log: true
						},
						click: function(){
							noteGWraper.addClass("hide", function(){
								noteGWraper.remove();
							});
							notification({
								text: "Подготовка...",
								image: "../image/ic_file_download_white_24dp_1x.gif",
								deadFunc: function(dead, notic){
									Window.DB.sendRequest("http://"+info.url+"preview/"+info.name+".jpg", {},
										function(previewFile){
											Window.DB.sendRequest("http://"+info.url+"full/"+info.name+"."+info.type, {},
												function(fullFile){
													//fullFile.type = "video/";
													//console.log(fullFile)
													saveBackgroundFileInSystem({
														file: new File([fullFile], info.name, {type: info.kind+"/"}),
														preview: new File([previewFile], info.name),
														isPixelArt: (info.type == "gif")? true : false,
														isLocal: false,
														urlFile: "http://"+info.url+info.name+"."+info.type
													}, function(){
														notification({text: "Фон успешно добавлен"});
														callback();																
													});
													notic.innerContent("Загрузка завершена");
													setTimeout(function(){
														dead();
													}, 1000);													
												},
												{blob: true, type: "GET"},
												function(val){
													notic.innerContent("Загрузка фона "+(Math.ceil(val*0.8)+20)+"%");
											});
										},
										{blob: true, type: "GET"},
										function(val){
											notic.innerContent("Загрузка фона "+Math.ceil(val*0.2)+"%");
									});
								}
							});							
						}
					}),					
					UI.createButton({
						settings: {class: "light false", content: "Закрыть", style: ["margin-right: 15px;"]},
						click: function(){
							noteGWraper.addClass("hide", function(){
								noteGWraper.remove();
							})
						}
					})
				]})		
			]
		});

		globalBody.appendChild(noteGWraper);
		setTimeout(function(){
			noteGWraper.removeClass("hide");
		}, 50);
	}

	function localCatalog(){
		content.clearContent();		
		var catalog = UI.createElem({class: "local_catalog"});
		content.appendChild(catalog);
		catalog.appendChild(UI.createElem({content:[
			UI.createInfoWrap({
				class: "load_files",
				text: "Загрузите фоны с компьютера",
				elem: UI.createButton({
					settings: {content: "Загрузить"},
					click: function(){localCatalogAddedLocalFile(localCatalog)}
				})
			})/*,
			UI.createInfoWrap({
				class: "load_files",
				text: "либо добавьте фон по URL",
				elem: UI.createButton({
					settings: {content: "Добавить"},
					click: function(){localCatalogAddedURL(localCatalog)}
				})
			}),
			UI.createInfoWrap({
				class: "load_files",
				text: "либо добавьте iframe",
				elem: UI.createButton({
					settings: {content: "Добавить"},
					click: function(){localCatalogAddedIFRAME(localCatalog)}
				})
			})*/
		]}));
		Window.DB.changeFile("/settings/backgroundsList.json", function(file){
			var url = Window.DB.get()+"backgrounds/preview/";
			if((file.video.length == 0)&&
			   (file.image.length == 0)&&
			   (file.color.length == 0)&&
			   (file.live.length == 0)) catalog.appendChild(UI.createElem({
				class: "charter",
				style: ["text-align: center;"],
				content: "У вас еще нет ни одного фона, загрузите их, либо добавьте свои"
			}));
			if(file.video.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Видео"
			}));
			file.video.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object, "video", i));
			});			
			if(file.image.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Изображения"
			}));
			file.image.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object, "image", i));
			});
			if(file.color.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Сплошные цвета"
			}));
			file.color.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object, "color", i));
			});
			if(file.live.length != 0) catalog.appendChild(UI.createElem({
				class: "charter",
				content: "Живые обои"
			}));
			file.live.forEach(function(object, i){
				catalog.appendChild(constructorPreview(object, "live", i));
			});

			function constructorPreview(object, type, number){
				return (function(){
					var preview = UI.createElem({
						class: "preview "+type+"_preview",
						style: [(type != "color")? "background-image: url('"+url+object.name+"');" : "background-color: "+object.color+";"],
						content: UI.createElem({
							class: "trie",
							style: ["width: 240px;"],
							content: UI.createButton({
								settings: {
									class: "false light",
									style: ["float: right;"],
									content: "Удалить"
								},
								click: function(){
									if(type != "color")
										Window.DB.changeFile("/settings/backgroundsList.json", function(file, save){
											file[type].splice(number, 1);
											if(object.urlFile) file.download.find(function(elem, i){
												if(elem == object.urlFile){
													file.download.splice(i, 1);
												}
											});
											save(file);											
										}, function(isSuccess){
											if(isSuccess) notification({text: "Фон успешно удален"});
											else notification({text: "Ошибка удаления фона"});
											preview.remove();//localCatalog();
										});
									else
										Window.DB.removeFile("/backgrounds/full/"+object.name, function(isSuccess){
											Window.DB.removeFile("/backgrounds/preview/"+object.name, function(isSuccess){
												Window.DB.changeFile("/settings/backgroundsList.json", function(file, save){
													file[type].splice(number, 1);
													if(object.urlFile) file.download.find(function(elem, i){
														if(elem == object.urlFile){
															file.download.splice(i, 1);
														}
													});
													save(file);											
												}, function(isSuccess){
													if(isSuccess) notification({text: "Фон успешно удален"});
													else notification({text: "Ошибка удаления фона"});
													preview.remove();//localCatalog();
												});
											});
										});
								}
							})
						})
					});
					return preview;
				})();
			}
		});						
	}

	globalBody.appendChild(BG_manager);
	setTimeout(function(){
		BG_manager.removeClass("hide");
	}, 50);
}

function notification(info){
	if(typeof info == "boolean") if(info) info = {}; else return;
	info = (info)? info : {};
	info.text = (info.text)? info.text : "Изменения сохранены";
	var contentNotic = UI.createElem({
		content: info.text,
		style: (info.image)? ["background-image: url("+info.image+")"] : []
	})
	var notic = UI.createElem({
		class: "notification hide",
		content: contentNotic
	});

	if(info.deadFunc) info.deadFunc(function(){
		notic.changeStyle("height");
		notic.addClass("hide", function(){notic.remove();});
	}, contentNotic)

	document.getElementById("tape").appendChild(notic.element);
	setTimeout(function(){
		notic.changeStyle([{
			tag: "height",
			value: (contentNotic.element.clientHeight+20)+"px"
		}]);
		notic.removeClass("hide", function(){
			if(!info.deadFunc){
				notic.changeStyle("height");
				notic.addClass("hide", function(){notic.remove();})
			}
		}, info.timeout? info.timeout : 3000);
	}, 50);	
}

function closeMenu(){
	header_menu = null;
	document.getElementById("interfaceWraper").classList.remove("hide");
	if(now_menu_expand.block) if(now_menu_expand.block.addedCloseFunction) now_menu_expand.block.addedCloseFunction();
	body.addClass("hide", function(){
		body.clearContent();
		body.addClass("zeroWidth");
		document.getElementById("interfaceWraper").classList.remove("openMenu");
	});	
}

function getPreviewFile(file, callback){
	/*
		Создание превью для фонов
	*/
	var canvas = document.createElement("canvas");
	var ctx = canvas.getContext("2d");

	if(~file.type.indexOf("video")){
		var video = document.createElement("video");
		video.setAttribute("src", URL.createObjectURL(file));
		video.setAttribute("autoplay","");
		video.setAttribute("muted","");

		video.onloadedmetadata = function(){
			video.currentTime = video.duration/2;			
			video.addEventListener('play', function(){
				canvas.width = video.videoWidth;
				canvas.height = video.videoHeight;
		    	ctx.drawImage(video, 0, 0);
				//console.log(canvas.toDataURL("image/png"));
		     	postprocessing(canvas);
		    },false);
		}
		
	}else{
		var img = document.createElement("img");
		img.setAttribute("src", URL.createObjectURL(file));

		img.onload = function(){			
			canvas.width = img.width;
			canvas.height = img.height;
			ctx.drawImage(img, 0, 0);			
			postprocessing(canvas);
		}
	}

	function postprocessing(cnvs){
		var oc   = document.createElement('canvas'),
		octx = oc.getContext('2d');
		if((cnvs.width > 250*4)&&(cnvs.height > 141*4)){
			oc.width  = cnvs.width  * 0.5;
			oc.height = cnvs.width * 0.5;

			octx.drawImage(cnvs, 0, 0, oc.width, oc.height);

			octx.drawImage(oc, 0, 0, oc.width * 0.5, oc.height * 0.5);

			cnvs.getContext("2d").drawImage(oc, 0, 0, oc.width * 0.5, oc.height * 0.5, 0, 0, cnvs.width,   cnvs.height);
		}

		var canvasResize = document.createElement("canvas");
		var ctxResize = canvasResize.getContext("2d");
		if(cnvs.width/cnvs.height < 1.7730496453900708){
			canvasResize.width = 250;
			canvasResize.height = 250/cnvs.width*cnvs.height;
		}else{
			canvasResize.width = 141/cnvs.height*cnvs.width;
			canvasResize.height = 141;
		}		
		ctxResize.drawImage(cnvs, 0, 0, cnvs.width, cnvs.height, 0, 0, canvasResize.width, canvasResize.height);
		oc.width  = 250;
		oc.height = 141;
		if(cnvs.width/cnvs.height < 1.7730496453900708){
			octx.drawImage(canvasResize, 0, -(canvasResize.height-141)*0.5, canvasResize.width, canvasResize.height);
		}else{
			octx.drawImage(canvasResize, -(canvasResize.width-250)*0.5, 0, canvasResize.width, canvasResize.height);
		}		
		oc.toBlob(function(blob){
			callback(blob);
		}, "image/jpeg", 1);
	}
}

function localCatalogAddedLocalFile(localCatalog, isReturnFile){
	var inputSpirit = document.createElement("input");
	inputSpirit.setAttribute("type", "file");
	inputSpirit.setAttribute("multiple", "true");
	inputSpirit.setAttribute("accept", "video/*,image/*");
	inputSpirit.click();													
	inputSpirit.onchange = function(event){	
		//console.log(event.srcElement.files)				
		localCatalogAddedLocalFileQueue(event.srcElement.files, 0, localCatalog, isReturnFile);		
	}
}
function localCatalogAddedLocalFileQueue(fileList, numb, localCatalog, isReturnFile){
	//console.log(fileList[numb]);
	var fileSave = {
		file: fileList[numb],
		isPixelArt: false,
		isLocal: true
	}
	var preview = UI.createElem({
		class: "preview load",
		content: UI.createElem({class: "load_spinner"})
	});
	getPreviewFile(fileSave.file, function(image){
		fileSave.preview = image;
		preview.changeStyle([{tag: "backgroundImage", value: "url("+URL.createObjectURL(image)+")"}]);
		preview.removeClass("load", function(){
			preview.clearContent();
		})
	});

	var loadActivity = UI.createElem({
		class: "loadFile_local hide",
		content: UI.createElem({
			class: "loadFile_local_content",
			content: [
				UI.createElem({
					class: "collum",
					content: preview
				}),
				UI.createElem({
					class: "collum",
					content: [
						UI.createElem({
							style: ["padding-left: 0px;", "padding-top: 0;"],
							tag: "h1",
							content: "Добавление фона"
						}),
						UI.createElem({
							style: ["margin: 0px -10px;", "padding: 5px 10px;", "background-color: #f1f1f1;"],
							content: UI.createElem({
								style: ["padding: 0px 10px;"],
								tag: "h2",
								content:
								   "имя - "+fileSave.file.name+"<br>"+
								   "размер - "+Math.round(Math.round(fileSave.file.size/1024)/10.24)/100+" Mb<br>"+
								   "тип - "+((fileSave.file.type.substring(0, fileSave.file.type.indexOf("/")) != "video")
								   				? "изображение"
								   				: "видео")+"<br>"+
								   "формат - "+fileSave.file.type.substring(fileSave.file.type.indexOf("/")+1)
							})
							
						}),
						UI.createCheckBox({
							settings: {
								style: ["border: none"]
							},
							content: "Это пиксельная графика",
							click: function(value){
								fileSave.isPixelArt = value;
							}
						}),
						UI.createElem({
							style: ["bottom: 10px;", "position: absolute;", "right: 10px;"],
							content: [
								UI.createButton({
									settings: {
										class: "false",
										content: "Отмена"
									},
									click: function(){
										loadActivity.addClass("hide", function(){
											loadActivity.remove();
										})
									}
								}),
								UI.createButton({
									settings: {
										style: ["margin-left: 10px"]
									},
									click: function(){
										saveBackgroundFileInSystem(fileSave, function(numbFile){
											loadActivity.addClass("hide", function(){
												loadActivity.remove();
												notification({text: "Фон успешно добавлен"});
												if(!isReturnFile) localCatalog();
												if(numb < fileList.length-1)
													localCatalogAddedLocalFileQueue(fileList, numb+1, localCatalog, isReturnFile);
												else if(isReturnFile){
													fileSave.number = numbFile-1;
													localCatalog(fileSave);
												}
											})																	
										});
									}
								})
							]
						})
					]
				})
			]
		})
	});
	globalBody.appendChild(loadActivity);
	setTimeout(function(){
		loadActivity.removeClass("hide");
	}, 50);
}
function localCatalogAddedURL(localCatalog){
	var inputURL = UI.createInput({
		settings: {
			style: ["width: 100%;"],
			special: {
				oninput: function(){
					Window.DB.sendRequest(inputURL.element.value, {}, function(resultBG){					
						//console.log(/*URL.createObjectURL(*/new File([resultBG], "test.jpg"))//)
					}, {blob: true, type: "GET"}, function(val){/*console.log(val)*/});
				}
			}
	}

	});
	var noteGWraper = UI.createElem({
		class: "manager_window hide",
		content: UI.createElem({
			class: "manager_wraper_content addURlManager",
			content: [				
				UI.createElem({
					class: "ahead",
					content: [
						UI.createElem({
							tag: "h1",
							content: "Добавление фона по URL"
						}),						
						UI.createButton({
							click: function(){
								noteGWraper.addClass("hide", function(){
									noteGWraper.remove();									
								}, 250);								
							},
							settings: {
								class: "clear close_manager",
								attr: [{tag: "title", value: "Закрыть"}]
							}
						})
					]
				}),
				UI.createElem({ class: "content", content: [
					UI.createElem({
						tag: "h2",
						content: "Добавьте фон по URL. URL должен быть прямо ведущий к фону"
					}),
					inputURL,
					UI.createElem()
				]})				
			]
		})		
	});

	globalBody.appendChild(noteGWraper);
	setTimeout(function(){
		inputURL.element.focus();
		noteGWraper.removeClass("hide");
	}, 50);
}
function localCatalogAddedIFRAME(localCatalog){
	
}
function moveWatch(callback, oldPosition){
	var saveChange_wraper = UI.createElem({class: "save_change_move_watch hide"});
	[{
		key: "x", info: "заморозить ось Y по центру"
	},{
		key: "y", info: "заморозить ось X по центру"
	}].forEach(createInfo);
	function createInfo(object){
		saveChange_wraper.appendChild(UI.createElem({
			tag: "div",
			style: ["margin-bottom: 10px;"],
			content: [
				UI.createElem({
					tag: "h2",
					class: "caption1 info buttHelp",
					style: [
						"margin: 0;",
						"margin-right: 10px;",
						"color: white;",
						"display: inline-block;",
						"background-color: rgba(255, 255, 255, 0.25);",
						"padding: 5px 10px;",
						"border-radius: 3px;",
						"font-size: 16px;"
					],
					content: object.key
				}),
				UI.createElem({
					tag: "h2",
					class: "caption1 info",
					style: ["color: white;", "display: inline-block;", "margin: 0;"],
					content: object.info
				})
			]
		}));
	}
	saveChange_wraper.appendChild(UI.createElem({
		style: ["margin-top: 20px;"],
		content: [
			UI.createButton({
				settings: {
					content: "Отмена",
					class: "false light",
					style: ["margin-right: 20px;"]
				},
				click: function(){
					document.getElementById("watch").classList.remove("moveWatch");
					document.getElementById("interfaceWraper").classList.remove("displayNone");
					saveChange_wraper.addClass("hide", function(){
						document.getElementById("interfaceWraper").classList.remove("hide");
						saveChange_wraper.remove();
					});
				}
			}),
			UI.createButton({
				settings: {
					content: "Сохранить изменения"
				},
				click: function(){
					callback(position);
					document.getElementById("watch").classList.remove("moveWatch");
					document.getElementById("interfaceWraper").classList.remove("displayNone");
					saveChange_wraper.addClass("hide", function(){
						document.getElementById("interfaceWraper").classList.remove("hide");
						saveChange_wraper.remove();
					});					
				}
			})
		]
	}));
	globalBody.appendChild(saveChange_wraper, function(){
		saveChange_wraper.removeClass("hide");
	}, 50);

	document.getElementById("watch").onmousedown = function(event){
		grabClock(document.getElementById("watch"), event);
	}

	var wraperSettings;
	var isGrab = false;
	var freeze = {x: false, y:false};
	var lastEvent;
	var position = oldPosition;

	function grabClock(node, startEvent){
		isGrab = true;
		let width = node.offsetWidth;
		let height = node.offsetHeight;
		var Y,X;
		freeze = {x: false, y:false}	
		let widthScreen = document.documentElement.clientWidth;
		let heightScreen = document.documentElement.clientHeight;
		//lastEvent = null;	
		let startPos = {
			x: startEvent.clientX,
			y: startEvent.clientY,
			offsetX: startEvent.clientX - node.getBoundingClientRect().left,
			offsetY: startEvent.clientY - node.getBoundingClientRect().top
		};
		node.classList.add("grabClock");
		node.style.right = null;
		node.style.left = null;
		node.style.top = null;
		node.style.bottom = null;
		node.style.position = "absolute";

		window.onmousemove = window.onmousedown =  function(event){
			if(!isGrab) return;		
			if(event) lastEvent = event;
			if(event){
				X = event.clientX-startPos.offsetX;
				Y = event.clientY-startPos.offsetY;
				X = (X < 0)? 0 : (X+width > widthScreen)? widthScreen-width : X;
				Y = (Y < 0)? 0 : (Y+height > heightScreen)? heightScreen-height : Y;
			}
			if(freeze.y){
				X = widthScreen/2-width/2;
				position.center.x = true;
			}else{
				position.center.x = false;
			}
			if(freeze.x){
				Y = heightScreen/2-height/2;
				position.center.y = true;
			}else{
				position.center.y = false;
			}
			node.style.top = Y+"px";
			node.style.left = X+"px";
			if(X+width > widthScreen-600) saveChange_wraper.addClass("left"); else saveChange_wraper.removeClass("left");
		}
		window.onmouseup = function(event){
			isGrab = false;
			node.classList.remove("grabClock");
			let isTop = (Y+height/2 < heightScreen/2);
			let isLeft = (X+width/2 < widthScreen/2);
			position.top = (isTop)? Y/heightScreen*100 : null;
			position.left = (isLeft)? X/widthScreen*100 : null;
			position.bottom = (isTop)? null : (heightScreen-Y-height)/heightScreen*100;
			position.right = (isLeft)? null : (widthScreen-X-width)/widthScreen*100;
			TIME.convertPosition(position, document.getElementById("watch"));			
		}
	}

	addEventListener('keydown', function(event) {
		if(event.keyCode == 88) document.body.classList.add("xCenter");
		if(event.keyCode == 89) document.body.classList.add("yCenter");

		if(!isGrab) return;
		//x
		if(event.keyCode == 88) freeze.x = true;
		//y
		if(event.keyCode == 89) freeze.y = true;
		window.onmousedown()
	});
	addEventListener('keyup', function(event){

		if(event.keyCode == 88) document.body.classList.remove("xCenter");
		if(event.keyCode == 89) document.body.classList.remove("yCenter");

		if(!isGrab) return;
		//x
		if(event.keyCode == 88) freeze.x = false;
		//y
		if(event.keyCode == 89) freeze.y = false;

		if(isGrab) window.onmousedown(lastEvent);
	});	
}
function newNote(){
	var isEdit;
	var subject = UI.createInput({
		settings: {class: "note_subject"},
		placeholder: "Введите заголовок"
	});
	var content = UI.createTextarea({
		settings: {class: "note_content"},
		placeholder: "Введите заметку"
	});
	var note_ahead = UI.createElem({
		tag: "h1",
		content: "Создание новой заметки"
	});
	var noteList = UI.createElem({class: "note_list"});
	function loadNotesList(){
		Window.DB.changeFile("/settings/settings.json", function(file){			
			noteList.clearContent();
			if(file.notes.length == 0) noteList.appendChild("У вас еще нет заметок")
			else{
				file.notes.forEach(function(noteInfo, i){
					noteInfoConstructor(noteInfo, i);
				});
			}
		});
	};
	loadNotesList();
	function noteInfoConstructor(noteInfo, numberInArr){
		noteList.appendChild(UI.createElem({
			class: "note_info "+((isEdit == noteInfo.create_date)? "select" : ""),
			content: [
				UI.createButton({
					settings: {
						class: "clear open_note"
					},
					click: function(event){
						Window.DB.changeFile("/note/note_"+noteInfo.create_date+".json", function(note){
							subject.element.value = note.subject;
							content.element.value = note.content.replace(/<br>/g, "\n");
							note_ahead.appendChild("Редактирование заметки");
							if(isEdit != numberInArr){
								event.srcElement.parentNode.classList.add("select");
								if(isEdit != undefined)
									event.srcElement.parentNode.parentNode.children[isEdit].classList.remove("select");
								isEdit = numberInArr;
							}							
						});
					}
				}),
				UI.createElem({tag: "h1", content: noteInfo.name}),
				UI.createElem({tag: "h2", content: (function(){
					var date = new Date((noteInfo.edit_date)? noteInfo.edit_date : noteInfo.create_date);
					return date.getDate()+" "+TIME.getMonth(date.getMonth())+" "+date.getFullYear()+" | "+
						date.getHours()+":"+TIME.toDouble(date.getMinutes());
				})()}),
				UI.createButton({
					settings: {
						class: "clear delete_note",
						attr: [{tag: "title", value: "Удалить заметку"}]
					},
					click: function(){
						if(isEdit == numberInArr){
							subject.element.value = "";
							content.element.value = "";
							content.element.focus();
							if(isEdit != undefined) noteList.element.children[isEdit].classList.remove("select");
							isEdit = undefined;
						}
						Window.DB.changeFile("/settings/settings.json", function(file, saveFile){
							Window.DB.removeFile("/note/note_"+noteInfo.create_date+".json", function(isSuccess){
								if(isEdit != undefined) isEdit = file.notes[isEdit].create_date;
								file.notes.splice(numberInArr, 1);
								saveFile(file);
							});
						}, function(isSuccess){
							note_ahead.appendChild("Создание новой заметки");
							notification({text: "Заметка удалена"});
							loadNotesList();
						});
					}
				})
			]			
		}));
		if(isEdit == noteInfo.create_date) isEdit = numberInArr;
	}	

	var noteGWraper = UI.createElem({
		class: "BGManager hide",
		content: [
			UI.createButton({
				settings: {class: "clear bgCloseButton"},
				click: function(){
					if((!subject.element.value)&&(!content.element.value)&&(isEdit == undefined))
						noteGWraper.addClass("hide", function(){
							noteGWraper.remove();									
						}, 250);
				}
			}),
			noteList,
			UI.createElem({
				class: "note_wraper",
				content: [				
					UI.createElem({
						class: "ahead",
						content: [
							note_ahead,						
							UI.createButton({
								click: function(){
									noteGWraper.addClass("hide", function(){
										noteGWraper.remove();									
									}, 250);								
								},
								settings: {
									class: "clear close_manager",
									attr: [{tag: "title", value: "Закрыть"}]
								}
							}),
							UI.createButton({
								click: function(){
									if((!subject.element.value)&&(!content.element.value)){
										notification({
											image: "../image/ic_error_white_24dp_1x.png",
											text: "Пустую заметку сохранить нельзя"
										})
										return;
									}	
									var dwn = document.createElement("a");
									dwn.setAttribute("href", URL.createObjectURL(new Blob([content.element.value], {
										type: "text/plain",
	                                	endings: 'native'
									})));
									dwn.setAttribute("download", ((subject.element.value)? subject.element.value :"Заметка")+".txt");
									dwn.click();
								},
								settings: {
									class: "clear note_download",
									attr: [{tag: "title", value: "Сохранить заметку на компьютер"}]
								}
							}),
							UI.createButton({
								click: function(){
									if((!subject.element.value)&&(!content.element.value)){
										notification({
											image: "../image/ic_error_white_24dp_1x.png",
											text: "Пустую заметку сохранить нельзя"
										})
										return;
									}						
									var noteName = (subject.element.value)? subject.element.value : (function(){
										var sub = content.element.value.substring(0, content.element.value.indexOf("."));
										sub = sub? sub : content.element.value;
										if(sub.length > 60) return sub.split("").splice(0, 55).join("")+"...";
										else return sub;
									})();
									var	noteDate = Date.now();
									if(isEdit != undefined){
										Window.DB.changeFile("/settings/settings.json", function(file, saveFile){					
											file.notes[isEdit].name = noteName;
											file.notes[isEdit].edit_date = noteDate;
											noteDate = file.notes[isEdit].create_date;							
											Window.DB.changeFile("/note/note_"+noteDate+".json", function(note, saveFile){					
												note = {
													subject: (subject.element.value)? subject.element.value : "",
													content: content.element.value.replace(/\r|\n/g, '<br>'),
													create_date: file.notes[isEdit].create_date
												}
												saveFile(note);
											}, function(isSuccess){
												saveFile(file);
											});
										}, function(isSuccess){
											isEdit = noteDate;
											loadNotesList();
											note_ahead.appendChild("Редактирование заметки");
											notification({text: "Изменения сохранены"});
										});
									}else{
										Window.DB.changeFile("/settings/settings.json", function(file, saveFile){									
											file.notes.push({name: noteName, create_date: noteDate});
											Window.DB.set("/note/", {
												file: new Blob([JSON.stringify({
													subject: (subject.element.value)? subject.element.value : "",
													content: content.element.value.replace(/\r|\n/g, '<br>'),
													create_date: noteDate
												})], {type: "application/json"}),
												name: "note_"+noteDate+".json"
											}, function(isSuccess){										
												saveFile(file);
											});
										}, function(isSuccess){
											isEdit = noteDate;	
											loadNotesList();
											note_ahead.appendChild("Редактирование заметки");
											notification({text: "Заметка сохранена"});
										});
									}		
								},
								settings: {
									class: "clear note_save",
									attr: [{tag: "title", value: "Сохранить заметку"}]
								}
							}),
							UI.createButton({
								click: function(){
									subject.element.value = "";
									content.element.value = "";
									content.element.focus();
									if(isEdit != undefined) noteList.element.children[isEdit].classList.remove("select");
									isEdit = undefined;
									note_ahead.appendChild("Создание новой заметки");
								},
								settings: {
									class: "clear note_new",
									attr: [{tag: "title", value: "Создать новую заметку"}]
								}
							})
						]
					}),
					subject,
					content
				]
			})
		]
	});

	globalBody.appendChild(noteGWraper);
	setTimeout(function(){
		content.element.focus();
		noteGWraper.removeClass("hide");
	}, 50);
}