/*--------------------------------------------------------------------------------------*/
/*-----------------------------ПЕРВАЯ ИНИЦИАЛИЗАЦИЯ-------------------------------------*/
/*--------------------------------------------------------------------------------------*/
if(!JSON.parse(localStorage.getItem("first_contact"))){
	window.open("welcome.html", "_self");
}

/*
	Загрузка данных пользователя
*/
Window.DB.changeFile("/settings/settings.json", function(file){	
	//console.log(file);
	document.getElementById("blind").style.backgroundColor = "rgba(0,0,0,"+[0, 0.17, 0.3, 0.6][file.background_dimming_level]+")";
	if((JSON.parse(localStorage.getItem("switch_background_when_opening_page")))
		||(Date.now() > JSON.parse(localStorage.getItem("next_check_background")))) getBackground(file);
	else getBackgroundNowSet(file);
	setInterval(function(){
		if(Date.now() > JSON.parse(localStorage.getItem("next_check_background")))
			Window.DB.changeFile("/settings/settings.json", function(file){
				getBackground(file);
			});	
	}, 30000);
	if(file.type_of_watch != 0)
		document.head.appendChild((function(){
			var script = document.createElement("script");
			script.setAttribute("src", "js/clock_module_"+file.type_of_watch+".js");
			script.setAttribute("id", "watch_module");
			script.onload = function(){
				Window.WATCH.drawClock();
				setInterval(Window.WATCH.updateWatch, 1000);			
			}
			return script;
		})());	
	document.getElementById("bodyWraper").classList.remove("hide");	
}, function(isSuccess){
	document.getElementById("bodyWraper").classList.remove("hide");
	if(!isSuccess) notification({
		image: "../image/ic_error_white_24dp_1x.png",
		text: "Ошибка загрузки данных",
		deadFunc: function(){}
	});
});

document.addEventListener('visibilitychange', function() {
	if(!document.hidden){
		console.info("upadate page...");
		if(document.getElementById("background"))	
			if(document.getElementById("background").play) document.getElementById("background").play();
	}else{
		if(document.getElementById("background"))	
			if(document.getElementById("background").pause) document.getElementById("background").pause();
	}
}, false);

function getBackground(settingsFile){	
	if(settingsFile.one_setting_for_selected_days){
		parseDay(settingsFile.switching_background_in_special);
	}else{
		parseDay(settingsFile["switching_background_in_"+["su", "mo", "tu", "we", "th", "fr", "sa"][new Date().getDay()]]);
	}

	function parseDay(daySettings){
		//console.log(daySettings)
		Window.DB.changeFile("/settings/backgroundsList.json", function(bgList, saveFile){
			var type_BG;
			var numb_BG_in_list;
			var time = new Date();
			if(daySettings.background_selection == 0){
				//СЛУЧАЙНЫЙ			
				var addMin = (function(){
					var min = 0;
					switch(daySettings.random_selection.period){
						case 1: min = 5; break;
						case 2: min = 30; break;
						case 3: min = 60; break;
						case 4: min = 360; break;
						case 5: min = 720; break;
						case 6: 
						case 0: min = 1440; break;
					}
					return new function(){
							if(min < 60){
								this.min = time.getMinutes() - (time.getMinutes() % min) + min;
								this.hour = time.getHours()*60;
								if(this.min >= 60){
									this.min = this.min % 60;
									this.hour = this.hour+60;
								}											
							}else{
								this.hour = (time.getHours()*60 < min)? min : time.getHours()*60 % min + min;
								this.min = min % 60;
							}
						}

				})();
				time.setHours(0, addMin.hour, 0, 0);
				time.setMinutes(addMin.min, 0, 0);
				localStorage.setItem("switch_background_when_opening_page",
					JSON.stringify(daySettings.random_selection.period == 0));
				var types = daySettings.random_selection.type.map(function(elem, i){
					return (elem)? ["video", "image", "color", "live"][i] : elem;
				}).filter(elem => elem);
				//console.log(types)
				//console.log(bgList)
				while(types.length > 0){
					//console.log(daySettings.random_selection.type)					
					type_BG = types[Math.round(Math.random()*(types.length-1))]
					//console.log(type_BG)
					//console.log(bgList[type_BG])
					if(bgList[type_BG].length == 0)
						types = types.filter(elem => elem != type_BG);
					else break;
				}
				//console.log(types)
				//console.log(type_BG)
				if(types.length == 0){
					notification({
						image: "../image/ic_error_white_24dp_1x.png",
						text: "Нет фонов",
						timeout: 6000
					});
					return;
				}
				numb_BG_in_list = Math.round((bgList[type_BG].length-1)*Math.random());
				bgList.background_set_now = [bgList[type_BG][numb_BG_in_list]];
				bgList.background_set_now[0].type = type_BG;
			}else{
				//КОНКРЕТНЫЙ
				time.setHours(0, 1440, 0, 0);
				time.setMinutes(0, 0, 0);
				localStorage.setItem("switch_background_when_opening_page", JSON.stringify(false));
				type_BG = "background_set_now";
				numb_BG_in_list = 0;
				bgList.background_set_now = [];
				bgList.background_set_now[0] = daySettings.specifically_selection;
			}
			localStorage.setItem("next_check_background", JSON.stringify(time.getTime()));
			console.info("NEW BACKGROUND NAME: "+bgList[type_BG][numb_BG_in_list].name)
			//type_BG = bgList[type_BG][numb_BG_in_list].type;
			setBackground(
				type_BG,
				bgList[type_BG][numb_BG_in_list].type,
				((bgList[type_BG][numb_BG_in_list].color)? 
					bgList[type_BG][numb_BG_in_list].color:
					bgList[type_BG][numb_BG_in_list].name),
				bgList[type_BG][numb_BG_in_list].isPixelArt
			);			
			saveFile(bgList);
		}, function(isSuccess, resultErr){
			//console.log(resultErr);
		});
	}
}

function getBackgroundNowSet(settingsFile){
	Window.DB.changeFile("/settings/backgroundsList.json", function(bgList, saveFile){
		setBackground(bgList.background_set_now[0].type,
					  bgList.background_set_now[0].type,
					  ((bgList.background_set_now[0].color)?
					  	bgList.background_set_now[0].color:
					  	bgList.background_set_now[0].name),
					  bgList.background_set_now[0].isPixelArt);	
	});
}

function setBackground(type, typeOfBG, name, isPixelArt){
	//console.log("type: "+type+" name: "+name+" isPixelArt: "+isPixelArt);
	if(typeOfBG == "color") document.getElementById("blind").classList.add("hide");
	else document.getElementById("blind").classList.remove("hide");
	console.info("NEXT SWITCH BACKGROUND: "+(new Date(JSON.parse(localStorage.getItem("next_check_background")))));
	//if(header_menu) header_menu.addClass("hide");
	if(document.getElementById("background")){
		document.getElementById("background").classList.add("hide");
		setTimeout(function(){
			document.getElementById("background").remove();
			setBackground(type, typeOfBG, name, isPixelArt);
		}, 300);
		return;	
	}
	switch(typeOfBG){
		case "video": 
			UI.createElem(document.getElementById("backgroundWraper")).appendChild(UI.createElem({
				tag: "video",
				attr: [
					{tag: "autoplay", value: "true"},
					{tag: "loop", value: "true"},
					{tag: "id", value: "background"},
					{tag: "src", value: Window.DB.get()+"/backgrounds/full/"+name}
				],
				class: ((isPixelArt)? "bgPIXEL" : "")+" hide",
				special: {
					onloadedmetadata: function(event){
						setTimeout(function(){
							event.srcElement.classList.remove("hide");
						}, 300);					
					},
					onerror: function(){
						console.error("ERROR LOAD VIDEO");
						notification({
							image: "../image/ic_error_white_24dp_1x.png",
							text: "Не удается загрузить фон",
							timeout: 6000
						});
					}
				}
			}));
			typeOfBG = "image";
			break;
		case "image": 
			UI.createElem(document.getElementById("backgroundWraper")).appendChild(UI.createElem({
				tag: "img",
				attr: [
					{tag: "id", value: "background"},
					{tag: "src", value: Window.DB.get()+"/backgrounds/full/"+name}
				],
				class: ((isPixelArt)? "bgPIXEL" : "")+" hide",
				special: {
					onload: function(event){
						setTimeout(function(){
							document.getElementById("background").classList.remove("hide");
						}, 300);					
					},
					onerror: function(){
						console.error("ERROR LOAD IMAGE");
						notification({
							image: "../image/ic_error_white_24dp_1x.png",
							text: "Не удается загрузить фон",
							timeout: 6000
						});
					}
				}
			}));
			typeOfBG = "image";
			break;
		case "color": 
			UI.createElem(document.getElementById("backgroundWraper")).appendChild(UI.createElem({
				tag: "div",
				class: "color hide",
				attr: [
					{tag: "id", value: "background"},
				],
				style: ["background-color: "+name+";"]
			}));
			setTimeout(function(){
				document.getElementById("background").classList.remove("hide");
			}, 10);
			typeOfBG = "color";
			break;
	}
	localStorage.setItem("bg_preview_now_set", "background-"+typeOfBG+": "+((typeOfBG == "color")? "" : "url('"+Window.DB.get()+"/backgrounds/preview/")+name+((typeOfBG == "color")? "" : "')"));
	if(header_menu)
		header_menu.addClass("hide", function(){
			header_menu.changeStyle("background-image");
			header_menu.changeStyle([{
				tag: localStorage.getItem("bg_preview_now_set").substring(0, localStorage.getItem("bg_preview_now_set").indexOf(":")),
				value: localStorage.getItem("bg_preview_now_set").substring(localStorage.getItem("bg_preview_now_set").indexOf(":")+2)
			}], function(){
				header_menu.removeClass("hide");
			});
		});
};

var body = UI.createElem(document.getElementById("settings_zone"));
var globalBody = UI.createElem(document.getElementById("bodyWraper"));

var hideCursorTimer;

document.getElementById("menu").onclick = openMenu;
document.getElementById("fullscreen").onclick = function(){	
	if(!window.screenTop && !window.screenY){
		document.body.webkitRequestFullScreen();
		document.getElementById("fullscreen").classList.add("full");
		document.getElementById("fullscreen").isFullscreen = true;		
		document.onmousemove = function(){
			document.getElementById("bodyWraper").classList.remove("hideCursor");
			clearTimeout(hideCursorTimer);
			hideCursorTimer = setTimeout(function(){
				//console.log("hide cursor");
				document.getElementById("bodyWraper").classList.add("hideCursor");
			}, 3000);
		}
	}else{
		document.webkitCancelFullScreen();
		document.getElementById("fullscreen").classList.remove("full");
		document.getElementById("fullscreen").isFullscreen = false;
		document.onmousemove = null;
		clearTimeout(hideCursorTimer);
		document.getElementById("bodyWraper").classList.remove("hideCursor");
	}
}
document.getElementById("new_note").onclick = newNote;

/*greeting();
function greeting(){
	console.log("Hey) What are you doing here?");
}
function drawADrawing(){
	console.log("Yeeah) Since you could find this picture, then you can go even further");
	console.log("");
	console.log("");
	console.log("");
	console.log("");
	console.log("");
	console.log("");
}*/

/*--------------------------------------------------------------------------------------*/
/*--------------------------------ТЕСТОВАЯ ЗОНА-----------------------------------------*/
/*--------------------------------------------------------------------------------------*/
/*test();
setTimeout(test, 500);
setTimeout(test, 1000);
function test(){
	notification({
		text: "Подготовка...",
		image: "../image/ic_file_download_white_24dp_1x.gif",
		deadFunc: function(dead, notic){
			setTimeout(function(){
				dead();		
				setTimeout(test, 500);
			}, 1000);			
		}
	});
}
notification({
	text: "Подготовка...",
	image: "../image/ic_file_download_white_24dp_1x.gif",
	deadFunc: function(dead, notic){			
	}
});
notification({
	text: "Подгот asd asd ass fad овка...",
	image: "../image/ic_file_download_white_24dp_1x.gif",
	deadFunc: function(dead, notic){			
	}
});*/