console.info("FIRST START APPLICATION");
console.info("create fileSystem and files for application");
Window.DB.getFS("/", function(rootFS){
	Window.DB.createFS(rootFS, "settings", function(isSuccess, settingsFS){
		Window.DB.createFS(rootFS, "note", function(isSuccess){
			Window.DB.createFS(rootFS, "backgrounds", function(isSuccess, backgroundsFS){
				Window.DB.createFS(backgroundsFS, "preview", function(isSuccess){
					Window.DB.createFS(backgroundsFS, "full", function(isSuccess){
						createData(settingsFS, backgroundsFS);
					});
				});
			});
		});
	});
});

function createData(settingsFS, backgroundsFS){
	Window.DB.set("/", {
		file: new Blob([JSON.stringify({
			/*
				Создание файла настроек
			*/
			background_switching_days: [true,true,true,true,true,true,true],
			type_of_watch: 1,
			//focus_search_field: true, 
			background_dimming_level: 2,
			one_setting_for_selected_days: true,
			switching_background_in_mo: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_tu: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_we: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_th: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_fr: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_sa: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_su: {
				background_selection: 0,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "",
					type: ""
				}
			},
			switching_background_in_special: {
				background_selection: 1,
				random_selection: {
					period: 2,
					type: [true, true, true, false]
				},
				specifically_selection: {
					name: "IMAGE_CATALOG_FILE_(0)_0000.jpg",
					type: "image"
				}
			},
			notes: []
		})], {type: "application/json"}),
		name: "settings.json"
	}, function(isSuccess){
		Window.DB.set("/", {
			file: new Blob([JSON.stringify({
				test_field: "test"
			})], {type: "application/json"}),
			name: "clock.json"
		}, function(isSuccess){
			Window.DB.set("/", {
				file: new Blob([JSON.stringify({
					video: [],
					image: [],
					color: [],
					live: [],
					background_set_now: [],
					download: []
				})], {type: "application/json"}),
				name: "backgroundsList.json"
			}, function(isSuccess){
				console.info("SUCCESS CREATE FILES FOR APPLICATION");	
				loadBG();
			}, settingsFS)
		}, settingsFS)
	}, settingsFS)
}

function loadBG(){
	document.getElementById("load_info").innerHTML = "Загрузка дополнительных даных";

	Window.DB.sendRequest("http://danilkinkinstudio.h1n.ru/backgrounds/full/0000.jpg", {}, function(full){
		Window.DB.sendRequest("http://danilkinkinstudio.h1n.ru/backgrounds/preview/0000.jpg", {}, function(preview){
			document.getElementById("load_info").innerHTML = "Финальная подготовка";
			saveBackgroundFileInSystem({
				file: new File([full], "0000.jpg", {type: "image/"}),
				preview: new File([preview], "0000.jpg"),
				urlFile: "http://danilkinkinstudio.h1n.ru/backgrounds/0000.jpg",
				isPixelArt: false,
				isLocal: false
			}, function(){
				Window.WATCH.createData(function(){
					localStorage.setItem("first_contact", JSON.stringify(true));
					localStorage.setItem("version", "1.0.8");				
					setTimeout(function(){
						document.getElementById("start_work").style = null;
						setTimeout(function(){
							document.body.classList.add("finish_load");
							console.log("well done!");
						}, 50);
					}, 1000);
				});																			
			});				
		},{type: "GET", blob: true}, function(percent){
			document.getElementById("load_info").innerHTML = "Загрузка дополнительных даных <br> "+(Math.round(percent*0.2+80))+"%";
		});			
	},{type: "GET", blob: true}, function(percent){
		document.getElementById("load_info").innerHTML = "Загрузка дополнительных даных <br> "+Math.round(percent*0.8)+"%";
	});	
}

function notification(object){
	console.log(object);
}

document.getElementById("start_work").onclick = function(){
	document.body.classList.add("hide");
	setTimeout(function(){
		window.open("main.html", "_self");
	}, 300);	
}