console.info("START UPDATE APPLICATION");

localStorage.setItem("version", "1.0.8");
Window.DB.changeFile("/settings/backgroundsList.json", function(a, s){a.color = []; a.live = []; s(a)});
Window.DB.changeFile("/settings/settings.json", function(a, s){
	a.switching_background_in_mo.random_selection.type = getType(a.switching_background_in_mo.random_selection.type);
	a.switching_background_in_tu.random_selection.type = getType(a.switching_background_in_tu.random_selection.type);
	a.switching_background_in_we.random_selection.type = getType(a.switching_background_in_we.random_selection.type);
	a.switching_background_in_th.random_selection.type = getType(a.switching_background_in_th.random_selection.type);
	a.switching_background_in_fr.random_selection.type = getType(a.switching_background_in_fr.random_selection.type);
	a.switching_background_in_sa.random_selection.type = getType(a.switching_background_in_sa.random_selection.type);
	a.switching_background_in_su.random_selection.type = getType(a.switching_background_in_su.random_selection.type);
	a.switching_background_in_special.random_selection.type = getType(a.switching_background_in_special.random_selection.type);
	s(a);

	function getType(type){
		switch(type){
			case 0: return [false, true,true, false];
			case 1: return [true, false ,true, false];
			case 2: return [true, true, true, false];
		}
	}
})

document.getElementById("start_work").onclick = function(){
	document.body.classList.add("hide");
	setTimeout(function(){
		window.open("main.html", "_self");
	}, 300);	
}