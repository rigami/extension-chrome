function saveBackgroundFileInSystem(file, callback){
	console.log(file);
	//(file.file.type.substring(0, file.file.type.indexOf("/")) != "video")
	file.type = file.file.type.substring(0, file.file.type.indexOf("/")) == "video";
	file.name = file.file.name.replace(/\r|\n/g, '_');
	file.prefix = ((file.type)? "VIDEO_" : "IMAGE_")+((file.isLocal)? "LOCAL_FILE_" : "CATALOG_FILE_");

	Window.DB.changeFile("/settings/backgroundsList.json", function(list, saveFile){
		if(file.type){
			file.name = file.prefix+"("+list.video.length+")_"+file.name;
			list.video.push({
				name: file.name,
				isPixelArt: file.isPixelArt
			});
		}else{
			file.name = file.prefix+"("+list.image.length+")_"+file.name;
			list.image.push({
				name: file.name,
				isPixelArt: file.isPixelArt
			});
		}
		if(!file.isLocal){
			list.download.push(file.urlFile);
			if(file.type)
				list.video[list.video.length-1].urlFile = file.urlFile;
			else
				list.image[list.image.length-1].urlFile = file.urlFile;
		}
		saveFile(list);
	}, function(isSuccess){
		if(!isSuccess){
			notification({
				text: "Ошибка записи файла"
			});
			return;
		}
		Window.DB.set("/backgrounds/full", {
			file: file.file,
			name: file.name
		}, function(isSuccess){
			if(!isSuccess){
				notification({
					text: "Ошибка записи файла"
				});
				return;
			}
			Window.DB.set("/backgrounds/preview", {
				file: file.preview,
				name: file.name
			}, function(isSuccess){
				if(!isSuccess){
					notification({
						text: "Ошибка записи файла"
					});
					return;
				}
				callback();
			});
		});
	});
}