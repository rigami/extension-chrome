/*
	Загрузка данных пользователя
*/
Window.DB.changeFile("/settings/settings.json", function(file){
	document.getElementById("blind").style.backgroundColor =
		"rgba(0,0,0,"+[0, 0.17, 0.3, 0.6][file.background_dimming_level]+")";
	//console.log(file);
	if((JSON.parse(localStorage.getItem("switch_background_when_opening_page")))
		||(Date.now() > JSON.parse(localStorage.getItem("next_check_background")))) getBackground(file);
	else getBackgroundNowSet(file);
	setInterval(function(){
		if(Date.now() > JSON.parse(localStorage.getItem("next_check_background")))
			Window.DB.changeFile("/settings/settings.json", function(file){
				getBackground(file);
			});	
	}, 30000);
	if(file.type_of_watch != 0)
		document.head.appendChild((function(){
			var script = document.createElement("script");
			script.setAttribute("src", "js/clock_module_"+file.type_of_watch+".js");
			script.setAttribute("id", "watch_module");
			script.onload = function(){
				Window.WATCH.drawClock();
				setInterval(Window.WATCH.updateWatch, 1000);			
			}
			return script;
		})());	
	document.getElementById("bodyWraper").classList.remove("hide");	
}, function(isSuccess){
	document.getElementById("bodyWraper").classList.remove("hide");
	if(!isSuccess) notification({
		image: "../image/ic_error_white_24dp_1x.png",
		text: "Ошибка загрузки данных",
		deadFunc: function(){}
	});
});

document.addEventListener('visibilitychange', function() {
	if(!document.hidden){
		console.info("upadate page...");
		if(document.getElementById("background"))	
			if(document.getElementById("background").play) document.getElementById("background").play();
	}else{
		if(document.getElementById("background"))	
			if(document.getElementById("background").pause) document.getElementById("background").pause();
	}
}, false);

function getBackground(settingsFile){	
	if(settingsFile.one_setting_for_selected_days){
		parseDay(settingsFile.switching_background_in_special);
	}else{
		parseDay(settingsFile["switching_background_in_"+["su", "mo", "tu", "we", "th", "fr", "sa"][new Date().getDay()]]);
	}

	function parseDay(daySettings){
		//console.log(daySettings)
		Window.DB.changeFile("/settings/backgroundsList.json", function(bgList, saveFile){
			var type_BG;
			var numb_BG_in_list;
			var time = new Date();
			if(daySettings.background_selection == 0){
				//СЛУЧАЙНЫЙ			
				var addMin = (function(){
					var min = 0;
					switch(daySettings.random_selection.period){
						case 1: min = 5; break;
						case 2: min = 30; break;
						case 3: min = 60; break;
						case 4: min = 360; break;
						case 5: min = 720; break;
						case 6: 
						case 0: min = 1440; break;
					}
					return new function(){
							if(min < 60){
								this.min = time.getMinutes() - (time.getMinutes() % min) + min;
								this.hour = time.getHours()*60;
								if(this.min >= 60){
									this.min = this.min % 60;
									this.hour = this.hour+60;
								}											
							}else{
								this.hour = (time.getHours()*60 < min)? min : time.getHours()*60 % min + min;
								this.min = min % 60;
							}
						}

				})();
				time.setHours(0, addMin.hour, 0, 0);
				time.setMinutes(addMin.min, 0, 0);
				localStorage.setItem("switch_background_when_opening_page",
					JSON.stringify(daySettings.random_selection.period == 0));
				switch(daySettings.random_selection.type){
					case 0: type_BG = "image"; break;
					case 1: type_BG = "video"; break;
					case 2: type_BG = ["image", "video"][Math.round(Math.random())]; break;
				}
				if(bgList[type_BG].length == 0) type_BG = (type_BG == "image")? "video" : "image";
				numb_BG_in_list = Math.round((bgList[type_BG].length-1)*Math.random());
				bgList.background_set_now = [bgList[type_BG][numb_BG_in_list]];
				bgList.background_set_now[0].type = type_BG;
			}else{
				//КОНКРЕТНЫЙ
				time.setHours(0, 1440, 0, 0);
				time.setMinutes(0, 0, 0);
				localStorage.setItem("switch_background_when_opening_page", JSON.stringify(false));
				type_BG = "background_set_now";
				numb_BG_in_list = 0;
				bgList.background_set_now = [];
				bgList.background_set_now[0] = daySettings.specifically_selection;
			}
			localStorage.setItem("next_check_background", JSON.stringify(time.getTime()));
			console.info("NEW BACKGROUND NAME: "+bgList[type_BG][numb_BG_in_list].name)
			//type_BG = bgList[type_BG][numb_BG_in_list].type;
			setBackground(
				type_BG,
				bgList[type_BG][numb_BG_in_list].type,
				bgList[type_BG][numb_BG_in_list].name,
				bgList[type_BG][numb_BG_in_list].isPixelArt
			);			
			saveFile(bgList);
		}, function(isSuccess, resultErr){
			//console.log(resultErr);
		});
	}
}

function getBackgroundNowSet(settingsFile){
	Window.DB.changeFile("/settings/backgroundsList.json", function(bgList, saveFile){
		setBackground(bgList.background_set_now[0].type,
					  bgList.background_set_now[0].type,
					  bgList.background_set_now[0].name,
					  bgList.background_set_now[0].isPixelArt);	
	});
}

function setBackground(type, typeOfBG, name, isPixelArt){
	//console.log("type: "+type+" name: "+name+" isPixelArt: "+isPixelArt);
	console.info("NEXT SWITCH BACKGROUND: "+(new Date(JSON.parse(localStorage.getItem("next_check_background")))));
	//if(header_menu) header_menu.addClass("hide");
	if(document.getElementById("background")){
		document.getElementById("background").classList.add("hide");
		setTimeout(function(){
			document.getElementById("background").remove();
			setBackground(type, typeOfBG, name, isPixelArt);
		}, 300);
		return;	
	}
	if(typeOfBG == "video"){
		UI.createElem(document.getElementById("backgroundWraper")).appendChild(UI.createElem({
			tag: "video",
			attr: [
				{tag: "autoplay", value: "true"},
				{tag: "loop", value: "true"},
				{tag: "id", value: "background"},
				{tag: "src", value: Window.DB.get()+"/backgrounds/full/"+name}
			],
			class: ((isPixelArt)? "bgPIXEL" : "")+" hide",
			special: {
				onloadedmetadata: function(event){
					setTimeout(function(){
						event.srcElement.classList.remove("hide");
					}, 300);					
				},
				onerror: function(){
					console.error("ERROR LOAD VIDEO");
					notification({
						image: "../image/ic_error_white_24dp_1x.png",
						text: "Не удается загрузить фон",
						timeout: 6000
					});
				}
			}
		}));
	}else{
		UI.createElem(document.getElementById("backgroundWraper")).appendChild(UI.createElem({
			tag: "img",
			attr: [
				{tag: "id", value: "background"},
				{tag: "src", value: Window.DB.get()+"/backgrounds/full/"+name}
			],
			class: ((isPixelArt)? "bgPIXEL" : "")+" hide",
			special: {
				onload: function(event){
					setTimeout(function(){
						document.getElementById("background").classList.remove("hide");
					}, 300);					
				},
				onerror: function(){
					console.error("ERROR LOAD IMAGE");
					notification({
						image: "../image/ic_error_white_24dp_1x.png",
						text: "Не удается загрузить фон",
						timeout: 6000
					});
				}
			}
		}));
	}
	localStorage.setItem("bg_preview_now_set", Window.DB.get()+"/backgrounds/preview/"+name);
	if(header_menu)
		header_menu.addClass("hide", function(){
			header_menu.changeStyle([{
				tag: "background-image",
				value: "url('"+localStorage.getItem("bg_preview_now_set")+"')"
			}], function(){
				header_menu.removeClass("hide");
			});
		});
};

var body = UI.createElem(document.getElementById("settings_zone"));
var globalBody = UI.createElem(document.getElementById("bodyWraper"));

var hideCursorTimer;

document.getElementById("menu").onclick = openMenu;
document.getElementById("fullscreen").onclick = function(){	
	if(!window.screenTop && !window.screenY){
		document.body.webkitRequestFullScreen();
		document.getElementById("fullscreen").classList.add("full");
		document.getElementById("fullscreen").isFullscreen = true;		
		document.onmousemove = function(){
			document.getElementById("bodyWraper").classList.remove("hideCursor");
			clearTimeout(hideCursorTimer);
			hideCursorTimer = setTimeout(function(){
				//console.log("hide cursor");
				document.getElementById("bodyWraper").classList.add("hideCursor");
			}, 3000);
		}
	}else{
		document.webkitCancelFullScreen();
		document.getElementById("fullscreen").classList.remove("full");
		document.getElementById("fullscreen").isFullscreen = false;
		document.onmousemove = null;
		clearTimeout(hideCursorTimer);
		document.getElementById("bodyWraper").classList.remove("hideCursor");
	}
}
document.getElementById("new_note").onclick = newNote;

/*--------------------------------------------------------------------------------------*/
/*--------------------------------ТЕСТОВАЯ ЗОНА-----------------------------------------*/
/*--------------------------------------------------------------------------------------*/
/*
notification({
	text: "Подготовка...",
	image: "../image/ic_file_download_white_24dp_1x.gif",
	deadFunc: function(dead, notic){
		
	}
});*/