(function(){
	var machine = {
		constructorSettingsClock: constructorSettingsClock,
		drawClock: drawClock,
		updateWatch: updateWatch
	};
	Window.WATCH = machine;

	function constructorSettingsClock(wraper, moveWatchFunction){
		console.log("CONNECT CLOCK MODULE 3");
		bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file){
			loadConstructor(file, wraper, moveWatchFunction);
		}, function(isSuccess){
			if(!isSuccess) createClockData(function(){
				console.info("CREATE DATA CLOCK");
				constructorSettingsClock(wraper, moveWatchFunction);
			});
		});
	}

	function loadConstructor(data, wraper, moveWatchFunction){
		wraper.appendChild([
			UI.createCheckBox({
				click: function(value){
					bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
						file.full_hour_format = value;
						data = file;
						saveFile(file);
					}, function(isSuccess){
						drawClock(data);
						//notification();
					});
				},
				value: data.full_hour_format,
				settings:{
					style: ["border-top: none;"]
				},
				content: "24 часовой формат"
			}),
			UI.createInfoWrap({
				text: "Размер часов",
				elem: UI.createSelection({
					options: ["Очень маленькие", "Маленькие", "Средние", "Большие", "Очень большие"],
					value: data.size,
					click: function(value){
						bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
							file.size = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							//notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Жирность шрифта часов - часы",
				elem: UI.createSelection({
					options: ["Очень тонкий", "Тонкий", "Нормальный", "Жирный", "Очень жирный"],
					value: data.width_clock_hours,
					click: function(value){
						bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
							file.width_clock_hours = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							//notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Жирность шрифта часов - минуты",
				elem: UI.createSelection({
					options: ["Очень тонкий", "Тонкий", "Нормальный", "Жирный", "Очень жирный"],
					value: data.width_clock_minuts,
					click: function(value){
						bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
							file.width_clock_minuts = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							//notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "Жирность шрифта даты",
				elem: UI.createSelection({
					options: ["Очень тонкий", "Тонкий", "Нормальный", "Жирный", "Очень жирный"],
					value: data.width_date,
					click: function(value){
						bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
							file.width_date = value;
							data = file;
							saveFile(file);
						}, function(isSuccess){
							drawClock(data);
							//notification();
						});
					}
				})
			}),
			UI.createInfoWrap({
				text: "",
				elem: UI.createButton({
					settings: {
						content: "Переместить часы"
					},
					click: function(value){
						moveWatchFunction(function(result){
							//console.log(result);
							bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file, saveFile){
								file.position = result;
								data = file;
								saveFile(file);
							}, function(isSuccess){
								drawClock(data);
								//notification();
							});
						}, data.position);
					}
				})
			})
		]);
	}

	function createClockData(callback){
		bgPage.Window.DB.set("/settings/", {
			file: new Blob([JSON.stringify({
				size: 3,
				width_clock_hours: 4,
				width_clock_minuts: 0,
				width_date: 1,
				full_hour_format: true,
				position: {
					top: null,
					left: null,
					right: null,
					bottom: null,
					center: {
						x: true,
						y: true
					}
				}
			})], {type: "application/json"}),
			name: "watch_3.json"
		}, callback)
	}
	/*
		Отрисока часов
	*/
	var time_format;

	function drawClock(data){
		if(!data){
			bgPage.Window.DB.changeFile("/settings/watch_3.json", function(file){
				drawClock(file);
			});
			return;
		}
		if(document.getElementById("watch")){
			UI.createElem(document.getElementById("watch")).addClass("hide", function(){
				document.getElementById("watch").remove();
				drawClock(data);
			});
			return;
		}	
		time_format = data.full_hour_format;
		var watch = UI.createElem({
			class: "watch hide",
			attr: [{tag: "id", value: "watch"}],
			style: [
				"padding: 8px;",
				"text-align: center;"
			]
		});		
		watch.appendChild([
			UI.createElem({
				tag: "h1",
				content: "error load watch",
				attr: [{tag: "id", value: "watch_element_clock_hours"}],
				style: [
					"margin: 0;",
					"color: #fff;",
					"line-height: 80%;",
					"padding: 0;",
					"font-size: "+(data.size*74+80)+"px;",
					"font-weight: "+["100", "300", "500", "700", "900"][data.width_clock_hours]+";"
				]
			}),
			UI.createElem({
				tag: "h1",
				content: "error load watch",
				attr: [{tag: "id", value: "watch_element_clock_minuts"}],
				style: [
					"margin: 0;",
					"color: #fff;",
					"line-height: 80%;",
					"padding: 0;",
					"font-size: "+(data.size*74+80)+"px;",
					"font-weight: "+["100", "300", "500", "700", "900"][data.width_clock_minuts]+";"
				]
			}),
			UI.createElem({
				tag: "h2",
				content: "перезагрузите страницу, либо восстановите данные",
				attr: [{tag: "id", value: "watch_element_date"}],
				style: [
					"margin: 0;",
					"color: #fff;",
					"font-size: "+([14, 27, 39, 48, 60][data.size])+"px;",
					"font-weight: "+["100", "300", "500", "700", "900"][data.width_date]+";"
				]
			})
		]);
		TIME.convertPosition(data.position, watch.element);
		document.getElementById("watch_wraper").appendChild(watch.element);
		updateWatch();
		setTimeout(function(){
			watch.removeClass("hide");
		}, 50);
	}

	function updateWatch(){
		if(!document.getElementById("watch")) return;
		var watch_clock_hours = document.getElementById("watch_element_clock_hours");
		var watch_clock_minuts = document.getElementById("watch_element_clock_minuts");
		var watch_date = document.getElementById("watch_element_date");
		var date = new Date();
		var time = TIME.getTime(time_format);

		watch_clock_hours.innerHTML = time.hours;
		watch_clock_minuts.innerHTML = time.minutes;
		watch_date.innerHTML = TIME.getDay(date.getDay(), true)+" "+TIME.toDouble(date.getDate())+
			" "+TIME.getMonth(date.getMonth(), true);
		//document.getElementById("litter").innerHTML = time.litter;
	}
}());