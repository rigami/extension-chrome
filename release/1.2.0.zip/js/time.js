(function(){
	var machine = {
		"getMonth": function(numb, isShort){
			if(isShort)
				switch(numb+1){
					case 1:  return "ЯНВ";   break;
					case 2:  return "ФЕВР";  break;
					case 3:  return "МАРТА"; break;
					case 4:  return "АПР";   break;
					case 5:  return "МАЯ";   break;
					case 6:  return "ИЮНЯ";  break;
					case 7:  return "ИЮЛЯ";  break;
					case 8:  return "АВГ";   break;
					case 9:  return "СЕНТ";  break;
					case 10: return "ОКТ";   break;
					case 11: return "НОЯБ";  break;
					case 12: return "ДЕК";   break;
				}
			else
				switch(numb+1){
					case 1:  return "ЯНВАРЯ";   break;
					case 2:  return "ФЕВРАЛЯ";  break;
					case 3:  return "МАРТА";    break;
					case 4:  return "АПРЕЛЯ";   break;
					case 5:  return "МАЯ";      break;
					case 6:  return "ИЮНЯ";     break;
					case 7:  return "ИЮЛЯ";     break;
					case 8:  return "АВГУСТА";  break;
					case 9:  return "СЕНТЯБРЯ"; break;
					case 10: return "ОКТЯБРЯ";  break;
					case 11: return "НОЯБРЯ";   break;
					case 12: return "ДЕКАБРЯ";  break;
				};
		},
		"getDay": function(numb, isShort){
			if(isShort)
				switch(numb){
					case 1: return "ПН"; break;
					case 2: return "ВТ"; break;
					case 3: return "СР"; break;
					case 4: return "ЧТ"; break;
					case 5: return "ПТ"; break;
					case 6: return "СБ"; break;
					case 0:
					case 7: return "ВС"; break;
				}
			else
				switch(numb){
					case 1: return "ПОНЕДЕЛЬНИК"; break;
					case 2: return "ВТОРНИК";     break;
					case 3: return "СРЕДА";       break;
					case 4: return "ЧЕТВЕРГ";     break;
					case 5: return "ПЯТНИЦА";     break;
					case 6: return "СУББОТА";     break;
					case 0:
					case 7: return "ВОСКРЕСЕНЬЕ"; break;
				}
		},
		"getTime": function(timeFormat){
			//timeFormat: |false - 12 format
			//			  |true  - 24 format
			//console.log((timeFormat))			
			var date = new Date();
			date = {
				hours: date.getHours(),
				minutes: date.getMinutes(),
				seconds: date.getSeconds()				
			};
			date.litter = (date.hours <= 12)? "am" : "pm";
			if((!timeFormat)&&(date.hours > 12)) date.hours = date.hours-12;
			for(key in date){
				if(key == "litter") continue;
				date[key] = machine.toDouble(date[key]);
				date[key] = date[key]+"";				
			}
			return date;
		},
		"toDouble": function(numb){
			return (numb < 10)? "0"+numb : numb;
		},
		"widthFont": function(val){
			val++;
			switch(val){
				case 1: return 100; break;
				case 2: return 300; break;
				case 3: return 500; break;
				case 4: return 700; break;
				case 5: return 900; break;
			}
		},
		"convertPosition": function(settings, node){
			//console.log(settings)
			node.style.right = null;
			node.style.left = null;
			node.style.top = null;
			node.style.bottom = null;
			node.style.position = "absolute";
			if(!settings.center.y){
				node.style.top = settings.top+"%";
				node.style.bottom = settings.bottom+"%";
				//node.parentNode.style.alignItems = "center";
			}
			if(!settings.center.x){
				//node.parentNode.style.justifyContent = "center";
				node.style.left = settings.left+"%";
				node.style.right = settings.right+"%";
			}
		}
	};

	window.TIME = machine;
})()