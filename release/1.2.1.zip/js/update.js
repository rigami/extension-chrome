console.info("START UPDATE APPLICATION");
var bgPage = chrome.extension.getBackgroundPage();
(function(){
	if(JSON.parse(localStorage.getItem("version")) >= 2) return;

	localStorage.setItem("training_stage", 1);
	localStorage.setItem("version", 2);
	Window.DB.getFS("/", function(rootFS){
		Window.DB.createFS(rootFS, "icons", function(isSuccess){
			Window.DB.changeFile("/settings/settings.json", function(a, s){
				a.hide_right_menu = true;
				a.use_site_panel = true;
				a.site_panel_substrate = true;
				a.site_panel_position = 3;
				s(a);	
			}, function(){
				Window.DB.set("/settings", {
					file: new Blob([JSON.stringify({
						favorites: [],
						all: []
					})], {type: "application/json"}),
					name: "sitesList.json"
				}, function(isSuccess){
					console.info("SUCCESS UPDATE APPLICATION");
				})
			});
		});
	});
})();

document.getElementById("start_work").onclick = function(){
	document.body.classList.add("hide");
	setTimeout(function(){
		window.open("main.html", "_self");
	}, 300);	
}