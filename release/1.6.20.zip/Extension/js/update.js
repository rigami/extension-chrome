console.info("START UPDATE APPLICATION");
var bgPage = chrome.extension.getBackgroundPage();
(function(){
	updateToVersion2(function(){
		updateToVersion3(function(){
			updateToVersion4(function(){
				updateToVersion5(function(){
					console.info("SUCCESS UPDATE APPLICATION");			
				})		
			})
		})
	});

})();

function updateToVersion2(callback){
	if(JSON.parse(localStorage.getItem("version")) >= 2){
		callback();
		return;
	}
	localStorage.setItem("training_stage", 1);
	localStorage.setItem("version", 2);
	Window.DB.getFS("/", function(rootFS){
		Window.DB.createFS(rootFS, "icons", function(isSuccess){
			Window.DB.changeFile("/settings/settings.json", function(a, s){
				a.hide_right_menu = true;
				a.use_site_panel = true;
				a.site_panel_substrate = true;
				a.site_panel_position = 3;
				s(a);	
			}, function(){
				Window.DB.set("/settings", {
					file: new Blob([JSON.stringify({
						favorites: [],
						all: []
					})], {type: "application/json"}),
					name: "sitesList.json"
				}, function(isSuccess){
					callback();
				})
			});
		});
	});
}
function updateToVersion3(callback){
	Window.DB.changeFile("/settings/settings.json", function(file){
		if(file.notes.length != 0) document.getElementById("save-note").classList.remove("hide");
		if(JSON.parse(localStorage.getItem("version")) >= 3){
			callback();
			return;
		}
		localStorage.setItem("training_stage", 8);
		localStorage.setItem("version", 3);
		Window.DB.getFS("/", function(rootFS){
			Window.DB.createFS(rootFS, "backups", function(isSuccess){
				callback();
			});
		});
	});
}
function updateToVersion4(callback){
	Window.DB.changeFile("/settings/settings.json", function(file){
		if(JSON.parse(localStorage.getItem("version")) >= 4){
			callback();
			return;
		}
		localStorage.setItem("training_stage", 8);
		localStorage.setItem("version", 4);
		Window.DB.changeFile("/settings/settings.json", function(a, s){
			a.open_site_panel_start = false;
			a.custom_tab_name = "clockTab";
			a.dark_theme = false;
			a.low_brightness_bg = false;
			s(a);	
		}, callback);
	});
}
function updateToVersion5(callback){
	Window.DB.changeFile("/settings/settings.json", function(file){
		if(JSON.parse(localStorage.getItem("version")) >= 5){
			callback();
			return;
		}
		localStorage.setItem("training_stage", 8);
		localStorage.setItem("version", 5);
		Window.DB.changeFile("/settings/settings.json", function(a, s){
			s(a);	
		}, callback);
	});
}

document.getElementById("start_work").onclick = function(){
	document.body.classList.add("hide");
	setTimeout(function(){
		window.open("main.html", "_self");
	}, 300);	
}

document.getElementById("download_notes").onclick = function(){
	Window.DB.changeFile("/settings/settings.json", function(file){
		if(file.notes.length != 0) downloadNotes(file.notes);
	});
}

function downloadNotes(files){
	queueProcessing(files.length, 0, function(next, i){
		Window.DB.changeFile("/note/note_"+files[i].create_date+".json", function(file){
			var dwn = document.createElement("a");
			dwn.setAttribute("href", URL.createObjectURL(new Blob([file.content], {
				type: "text/plain",
		    	endings: 'native'
			})));
			dwn.setAttribute("download", ((file.subject)? file.subject :"Заметка")+".txt");
			dwn.click();
			next();
		});
	}, function(){

	});
	function queueProcessing(size, now, operation, finishCallback){
		if(size == now){
			if(finishCallback) finishCallback();
			return;
		}
		operation(function(){
			queueProcessing(size, now+1, operation, finishCallback)
		}, now);
	}
}